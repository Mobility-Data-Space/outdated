import { json } from "d3-fetch"
import { colorGroupwise, applyPresets } from "./graph"

const BASE_API = "/"

function appendDateRangeParameter(url) {
    const dateRange = window.getDateRange()
    if (dateRange) {
        if (url.includes("?"))
            return `${url}&from=${encodeURIComponent(dateRange[0].toISOString())}&to=${encodeURIComponent(dateRange[1].toISOString())}`
        return `${url}?from=${encodeURIComponent(dateRange[0].toISOString())}&to=${encodeURIComponent(dateRange[1].toISOString())}`
    }
    return url
}

export function download() {
    window.open(appendDateRangeParameter("/download"), "_blank")
}

export function dataspaceLayout(base = BASE_API) {
    return json(appendDateRangeParameter(`${base}dataspace-layout`))
}
export function connectorData(id, base = BASE_API) {
    return json(appendDateRangeParameter(`${base}connector-data/${encodeURIComponent(id)}`))
}
export function resourceLink(id1, id2, base = BASE_API) {
    return json(appendDateRangeParameter(`${base}resource-link?sourceId=${encodeURIComponent(id1)}&targetId=${encodeURIComponent(id2)}`))
}

export async function presets() {
    return json(new URL('../../data/presets.json', import.meta.url).href)
}

export async function tryEnrichNode(node, base = BASE_API) {
    const enrichedNode = { ...node, name: node.name || node.id }
    if (node.type === "connector") {
        try {
            const additionalData = await connectorData(node.id, base)
            return { ...enrichedNode, ...additionalData }
        } catch (e) {
            console.error("unabled to enrich data", node, e)
        }
    }
    return enrichedNode
}

export async function tryEnrichLink(link, base = BASE_API) {
    try {
        const resources = await resourceLink(link.source, link.target, base)
        return { resources, ...link }
    } catch (e) {
        console.log("unable to enrich link", link, e)
    }
    return link
}


/**
 * Returns the dataspace-layout and calls tryEnrichNode on the nodes to fetch addtional data.
 * @param {string} base base api url (should end with /)
 * @returns 
 */
export async function fullDataspaceLayout(base = BASE_API) {
    const basicLayout = await dataspaceLayout(base)
    const p = presets()
    const enrichtedNodes = await Promise.all(basicLayout.nodes.map(node => tryEnrichNode(node, base)))


    const enrichedLinks = await Promise.all(basicLayout.links.map(link => {
        return link
    }))
    return colorGroupwise(applyPresets({
        ...basicLayout,
        nodes: enrichtedNodes,
        links: enrichedLinks
    }, await p),
        "#444"
        // "#ff0"

        /*"#a6a6a6"*/
        /*"rgb(55, 55, 55)"*/
    )
}