export function renderDatePicker() {
    const container = document.querySelector("#datepickerSelection")
    const inputs = container.querySelectorAll("input")
    const dateRangePicker = new DateRangePicker(container, {
        allowOneSidedRange: false,
        autohide: false,
        beforeShowDay: null,
        beforeShowDecade: null,
        beforeShowMonth: null,
        beforeShowYear: null,
        calendarWeeks: false,
        clearBtn: false,
        dateDelimiter: ',',
        datesDisabled: [],
        daysOfWeekDisabled: [],
        daysOfWeekHighlighted: [],
        format: 'dd.mm.yyyy',
        language: 'en',
        maxDate: new Date(),
        maxNumberOfDates: 1,
        maxView: 3,
        minDate: null,
        nextArrow: '»',
        orientation: 'auto',
        pickLevel: 0,
        prevArrow: '«',
        showDaysOfWeek: true,
        showOnClick: true,
        showOnFocus: true,
        startView: 0,
        title: '',
        todayBtn: false,
        todayHighlight: true,
        updateOnBlur: true,
        weekStart: 1,
    })

    const startDate = new Date()
    startDate.setDate(1)
    const endDate = new Date()

    dateRangePicker?.datepickers[0]?.setDate?.(startDate)
    dateRangePicker?.datepickers[1]?.setDate?.(endDate)
        // hide datepickers on blur
        ;[...inputs].forEach(input => input.onblur = () => {
            dateRangePicker.datepickers.forEach(picker => picker.hide())
        })

    dateRangePicker?.datepickers?.forEach(datepicker => {
        datepicker.element.addEventListener("changeDate", () => {
            window.refresh?.()
        })
        datepicker.element.addEventListener("hide", () => {
            window.refresh?.()
        })
    })

    window.getDateRange = () => {
        return [
            dateRangePicker?.datepickers[0]?.getDate?.() ?? startDate,
            new Date((dateRangePicker?.datepickers[1]?.getDate?.() ?? endDate).setHours(23, 59, 59, 999))
        ]
    }

}