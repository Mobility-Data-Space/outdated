package de.fraunhofer.iais.eis.ids.index.common.persistence.mds;

public enum TransportationMode {
    RAIL, ROAD, WATER, AIR
}
