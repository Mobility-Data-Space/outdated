package de.fraunhofer.iais.eis.ids.index.common.persistence;

public interface Worker {
    void doSomething() throws Exception;
}
