### Generate self signed certificates for localhost

- server.cert
- server.key
