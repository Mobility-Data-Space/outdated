#!/usr/bin/env bash

set -eo pipefail

. ${FILE_PATH}test.sh
