# Changelog
All notable changes to this project will be documented in this file.

## [2.0.0] - 30.08.2021

### Added
- Upgraded underlying connector architecture to DSC v6.1.0

### Changed
-

### Fixed
-
