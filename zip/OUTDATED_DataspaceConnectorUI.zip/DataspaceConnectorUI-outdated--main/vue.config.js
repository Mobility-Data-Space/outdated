module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
  devServer: {
    allowedHosts: "all",
  }
}