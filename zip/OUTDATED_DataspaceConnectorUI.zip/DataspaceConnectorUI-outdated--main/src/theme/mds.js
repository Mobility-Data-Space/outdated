export default {
    // e.g. sidebar background
    navigationBackground: '#ff0',
    primary: '#000',
    primary2: '#000',
    primary3: '#d8daac',
    primary4: '#E8F5F2',
    secondary: '#626143',
    accent: '#000',
    accent2: '#EF935E',
    accent3: '#F7C7AC',
    accent4: '#FDF0E8',
    // e.g background of selected nav element
    primaryhighlight: '#fff',
    // e.g. hover of nav element
    primaryhighlight2: '#f5f54c',
    error: '#FF5252',
    info: '#FDF0E8',
    success: '#4CAF50',
    warning: '#FFC107',
    textgrey: '#cccccc',
    // e.g. normal text
    text1: '#0F0F0F',
    // e.g. Background of logo section
    text4: '#979595',
    // e.g. navigation text
    lighttext: '#000'
};
