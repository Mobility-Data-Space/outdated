import FlowChart from './FlowChart';

FlowChart.install = function(Vue) {
  Vue.component(FlowChart.name, FlowChart);
};

export default FlowChart;