<template src="./NavigationMenu.html"></template>
<script src="./NavigationMenu.js"></script>
<style src="./NavigationMenu.css">
</style>
