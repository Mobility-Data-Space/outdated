<template src="./NTimesUsage.html"></template>
<script src="./NTimesUsage.js"></script>
<style src="./NTimesUsage.css"></style>
