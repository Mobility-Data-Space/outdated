<template src="./ProvideAccess.html"></template>
<script src="./ProvideAccess.js"></script>
<style src="./ProvideAccess.css"></style>
