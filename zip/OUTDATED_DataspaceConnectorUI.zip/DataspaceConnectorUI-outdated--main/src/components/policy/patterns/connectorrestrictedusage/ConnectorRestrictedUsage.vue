<template src="./ConnectorRestrictedUsage.html"></template>
<script src="./ConnectorRestrictedUsage.js"></script>
<style src="./ConnectorRestrictedUsage.css"></style>  
