<template src="./UsageDuringInterval.html"></template>
<script src="./UsageDuringInterval.js"></script>
<style src="./UsageDuringInterval.css"></style>
