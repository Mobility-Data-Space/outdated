<template src="./ProhibitAccess.html"></template>
<script src="./ProhibitAccess.js"></script>
<style src="./ProhibitAccess.css"></style>
