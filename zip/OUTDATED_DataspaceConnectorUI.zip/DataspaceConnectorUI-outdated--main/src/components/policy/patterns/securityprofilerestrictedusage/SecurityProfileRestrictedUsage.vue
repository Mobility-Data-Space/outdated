<template src="./SecurityProfileRestrictedUsage.html"></template>
<script src="./SecurityProfileRestrictedUsage.js"></script>
<style src="./SecurityProfileRestrictedUsage.css"></style> 
