<template src="./ActiveContractsCard.html"></template>
<script src="./ActiveContractsCard.js"></script>
<style src="./ActiveContractsCard.css"></style>
