<template src="./OwnUrlCard.html"></template>
<script src="./OwnUrlCard.js"></script>
<style src="./OwnUrlCard.css"></style>
