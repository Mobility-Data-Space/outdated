<template src="./FileTypesCard.html"></template>
<script src="./FileTypesCard.js"></script>
<style src="./FileTypesCard.css"></style>
