<template src="./PolicyTemplatesCard.html"></template>
<script src="./PolicyTemplatesCard.js"></script>
<style src="./PolicyTemplatesCard.css"></style>
