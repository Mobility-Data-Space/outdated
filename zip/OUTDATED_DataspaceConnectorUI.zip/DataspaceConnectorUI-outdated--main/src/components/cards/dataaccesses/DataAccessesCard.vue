<template src="./DataAccessesCard.html"></template>
<script src="./DataAccessesCard.js"></script>
<style src="./DataAccessesCard.css"></style>
