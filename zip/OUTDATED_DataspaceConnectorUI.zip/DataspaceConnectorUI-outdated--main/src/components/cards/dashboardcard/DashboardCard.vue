<template src="./DashboardCard.html"></template>
<script src="./DashboardCard.js"></script>
<style src="./DashboardCard.css"></style>
