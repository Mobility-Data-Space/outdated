
export default {
    data() {
        return {};
    },
    mounted: function () {

    },
    methods: {}

};
