<template src="./DataSourcesCard.html"></template>
<script src="./DataSourcesCard.js"></script>
<style src="./DataSourcesCard.css"></style>
