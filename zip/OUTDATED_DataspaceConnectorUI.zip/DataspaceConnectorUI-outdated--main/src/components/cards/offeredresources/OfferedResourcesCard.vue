<template src="./OfferedResourcesCard.html"></template>
<script src="./OfferedResourcesCard.js"></script>
<style src="./OfferedResourcesCard.css"></style>
