<template src="./SourceTypesCard.html"></template>
<script src="./SourceTypesCard.js"></script>
<style src="./SourceTypesCard.css"></style>
