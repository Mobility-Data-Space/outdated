<template src="./InfoBox.html"></template>
<script src="./InfoBox.js"></script>
<style src="./InfoBox.css"></style>
