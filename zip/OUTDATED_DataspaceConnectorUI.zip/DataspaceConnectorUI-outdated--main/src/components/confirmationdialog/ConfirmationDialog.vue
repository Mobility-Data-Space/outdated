<template src="./ConfirmationDialog.html"></template>
<script src="./ConfirmationDialog.js"></script>
<style src="./ConfirmationDialog.css"></style>
