<template src="./AppsPage.html"></template>
<script src="./AppsPage.js"></script>
<style src="./AppsPage.css"></style>
