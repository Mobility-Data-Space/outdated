<template src="./IDSResourcesPage.html"></template>
<script src="./IDSResourcesPage.js"></script>
<style src="./IDSResourcesPage.css"></style>
