<template src="./AddPolicyDialog.html"></template>
<script src="./AddPolicyDialog.js"></script>
<style src="./AddPolicyDialog.css"></style>