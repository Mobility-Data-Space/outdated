<template src="./ResourceCatalogsPage.html"></template>
<script src="./ResourceCatalogsPage.js"></script>
<style src="./ResourceCatalogsPage.css"></style>
