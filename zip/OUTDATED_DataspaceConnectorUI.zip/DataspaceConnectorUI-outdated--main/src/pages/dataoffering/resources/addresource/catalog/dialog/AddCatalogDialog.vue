<template src="./AddCatalogDialog.html"></template>
<script src="./AddCatalogDialog.js"></script>
<style src="./AddCatalogDialog.css"></style>
