<template src="./PolicyTab.html"></template>
<script src="./PolicyTab.js"></script>
<style src="./PolicyTab.css"></style>
