<template src="./ResourceOntologyPage.html"></template>
<script src="./ResourceOntologyPage.js"></script>
<style src="./ResourceOntologyPage.css"></style>
