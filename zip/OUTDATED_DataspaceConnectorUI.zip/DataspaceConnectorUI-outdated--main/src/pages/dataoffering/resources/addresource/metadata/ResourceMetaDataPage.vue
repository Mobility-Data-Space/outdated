<template src="./ResourceMetaDataPage.html"></template>
<script src="./ResourceMetaDataPage.js"></script>
<style src="./ResourceMetaDataPage.css"></style>
