<template src="./AddResourceFilePage.html"></template>
<script src="./AddResourceFilePage.js"></script>
<style src="./AddResourceFilePage.css"></style>
