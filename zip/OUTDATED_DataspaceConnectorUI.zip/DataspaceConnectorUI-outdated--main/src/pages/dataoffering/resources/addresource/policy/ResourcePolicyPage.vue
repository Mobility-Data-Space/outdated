<template src="./ResourcePolicyPage.html"></template>
<script src="./ResourcePolicyPage.js"></script>
<style src="./ResourcePolicyPage.css"></style>
