<template src="./AddResourcePage.html"></template>
<script src="./AddResourcePage.js"></script>
<style src="./AddResourcePage.css"></style>
