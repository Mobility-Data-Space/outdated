<template src="./ResourceRepresentationPage.html"></template>
<script src="./ResourceRepresentationPage.js"></script>
<style src="./ResourceRepresentationPage.css"></style>
