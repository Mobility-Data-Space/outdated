import FileUpload from "@/components/fileupload/FileUpload.vue";

export default {
    components: {
        FileUpload
    },
    data() {
        return {
            path: null
        };
    },
    mounted: function () {},
    methods: {}
}
