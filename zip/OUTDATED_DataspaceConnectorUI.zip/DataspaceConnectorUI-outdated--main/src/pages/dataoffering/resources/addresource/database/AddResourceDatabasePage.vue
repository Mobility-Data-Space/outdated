<template src="./AddResourceDatabasePage.html"></template>
<script src="./AddResourceDatabasePage.js"></script>
<style src="./AddResourceDatabasePage.css"></style>
