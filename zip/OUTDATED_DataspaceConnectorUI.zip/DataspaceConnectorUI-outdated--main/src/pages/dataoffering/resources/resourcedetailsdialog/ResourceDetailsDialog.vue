<template src="./ResourceDetailsDialog.html"></template>
<script src="./ResourceDetailsDialog.js"></script>
<style src="./ResourceDetailsDialog.css"></style>
