<template src="./ResourceReferenceDialog.html"></template>
<script src="./ResourceReferenceDialog.js"></script>
<style src="./ResourceReferenceDialog.css"></style>
