<template src="./ResourceAgreementsDialog.html"></template>
<script src="./ResourceAgreementsDialog.js"></script>
<style src="./ResourceAgreementsDialog.css"></style>
