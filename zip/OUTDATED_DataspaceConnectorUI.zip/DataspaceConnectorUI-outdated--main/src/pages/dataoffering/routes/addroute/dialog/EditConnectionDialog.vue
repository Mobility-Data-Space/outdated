<template src="./EditConnectionDialog.html"></template>
<script src="./EditConnectionDialog.js"></script>
<style src="./EditConnectionDialog.css"></style>
