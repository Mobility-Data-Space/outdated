export default {
    components: {

    },
    data() {
        return {
            dialog: false,
            title: ""
        };
    },
    mounted: function () {},
    methods: {
        save() {

        }
    }
};
