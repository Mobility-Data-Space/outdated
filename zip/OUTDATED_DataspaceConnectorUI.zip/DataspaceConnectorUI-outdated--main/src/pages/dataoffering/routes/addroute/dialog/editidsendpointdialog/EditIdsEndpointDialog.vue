<template src="./EditIdsEndpointDialog.html"></template>
<script src="./EditIdsEndpointDialog.js"></script>
<style src="./EditIdsEndpointDialog.css"></style>
