<template src="./EditNodeDialog.html"></template>
<script src="./EditNodeDialog.js"></script>
<style src="./EditNodeDialog.css"></style>
