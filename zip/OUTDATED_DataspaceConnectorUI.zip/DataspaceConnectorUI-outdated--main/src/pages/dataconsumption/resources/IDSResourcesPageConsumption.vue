<template src="./IDSResourcesPageConsumption.html"></template>
<script src="./IDSResourcesPageConsumption.js"></script>
<style src="./IDSResourcesPageConsumption.css"></style>
