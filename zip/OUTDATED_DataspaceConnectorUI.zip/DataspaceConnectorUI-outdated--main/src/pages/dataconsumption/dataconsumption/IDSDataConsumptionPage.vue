<template src="./IDSDataConsumptionPage.html"></template>
<script src="./IDSDataConsumptionPage.js"></script>
<style src="./IDSDataConsumptionPage.css"></style>
