<template src="./ArtifactDialog.html"></template>
<script src="./ArtifactDialog.js"></script>
<style src="./ArtifactDialog.css"></style>
