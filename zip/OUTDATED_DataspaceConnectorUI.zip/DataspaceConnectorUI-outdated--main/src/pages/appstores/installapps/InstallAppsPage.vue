<template src="./InstallAppsPage.html"></template>
<script src="./InstallAppsPage.js"></script>
<style src="./InstallAppsPage.css"></style>
