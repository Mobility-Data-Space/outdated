<template src="./AppStoresPage.html"></template>
<script src="./AppStoresPage.js"></script>
<style src="./AppStoresPage.css"></style>
