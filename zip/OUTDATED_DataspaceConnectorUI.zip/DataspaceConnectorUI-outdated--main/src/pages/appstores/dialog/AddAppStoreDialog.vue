<template src="./AddAppStoreDialog.html"></template>
<script src="./AddAppStoreDialog.js"></script>
<style src="./AddAppStoreDialog.css"></style>
