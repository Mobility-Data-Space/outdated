<template src="./SubscribeResourcePage.html"></template>
<script src="./SubscribeResourcePage.js"></script>
<style src="./SubscribeResourcePage.css"></style>
