<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "App",

  components: {},

  data: () => ({ drawer: null }),
};
</script>
<link rel="stylesheet" href="styles/default.css">
