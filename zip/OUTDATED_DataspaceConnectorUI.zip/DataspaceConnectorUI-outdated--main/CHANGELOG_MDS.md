# Changelog
All notable changes to this project will be documented in this file.

## [10.2.2-mds1] - 2022-12-06


## [10.2.1-mds1] - 2022-11-14


## [10.2.0-mds1] - 2022-11-03

### Changed
- Updated ontology release 2210


## [10.1.0-mds1] - 2022-10-06


## [10.0.1-mds] - 2022-08-23


## [10.0.0-mds] - 2022-07-04 (compatible with DSC 7.1.0)

### Added
- Custom MDS-related properties for Resources

### Fix
- Adjust image name to `dataspaceconnectorui`
- Adjust image source `https://github.com/Mobility-Data-Space/DataspaceConnectorUI` of Dockerfile
