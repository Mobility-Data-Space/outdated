# Clearing House Dashboard

The Clearing House Dashboard uses Clearing House (CH) Logging Data zu visualize a Data Space.

![Context](docs/dashboard_context.png)

Since the CH only contains logs of contracts and request-response-logs but no meta-data about resources or participants,
it must synchronize this data from other sources, like the Broker and the Connector self-descriptions.

![Blocks](docs/dashboard_buiding_blocks.png)


## Configuration options
### General
| Property | Environment variable        | Description           | Defaults  |
| ------------- | ------------- |-------------| -----|
| logginghouse.update.enabled | UPDATE_ENABLED | Enables synchronization of logs. | false |
| logginghouse.update.initialdelay | UPDATE_INITIAL_DELAY | Time to wait before the first log sync after program starts. | 20s |
| logginghouse.update.fixeddelay | UPDATE_FIXED_DELAY | Time between log syncs. | 15m |
| logginghouse.logsync.enabled | LOG_SYNC_ENABLED | Enables synchronization of logs. | false |
| logginghouse.logsync.initialdelay | LOG_SYNC_INITIAL_DELAY | Time to wait before the first log sync after program starts. | 1m |
| logginghouse.logsync.fixeddelay | LOG_SYNC_FIXED_DELAY | Time between log syncs. | 1h |
| logginghouse.brokersync.enabled | BROKER_SYNC_ENABLED | Enables synchronization of resource meta-data from Broker. | false |
| logginghouse.brokersync.initialdelay | BROKER_SYNC_INITIAL_DELAY | Time to wait before the first Broker sync after program starts. | 40s |
| logginghouse.brokersync.fixeddelay | BROKER_SYNC_FIXED_DELAY | Time between Broker syncs. | 15m |
| logginghouse.connectorsync.enabled | CONNECTOR_SYNC_ENABLED | Enables synchronization of resource meta-data from the Connectors. | false |
| logginghouse.connectorsync.initialdelay | CONNECTOR_SYNC_INITIAL_DELAY | Time to wait before the first Connectror sync after program starts. | 40s |
| logginghouse.connectorsync.fixeddelay | CONNECTOR_SYNC_FIXED_DELAY | Time between Connector syncs. | 15m |

### Clearing House Config
| Property | Environment variable        | Description           | Defaults  |
| ------------- | ------------- |-------------| -----|
| micronaut.http.services.documentapi.url | MICRONAUT_HTTP_SERVICES_DOCUMENTAPI_URL | The URL of the Clearing House Document API. | |
| mongodb.servers.processdb.uri | PROCESS_DB_URI| The url of the Clearing House Process database. E.g. mongodb:/clearinghouse:27019/process| |
| micronaut.security.oauth2.clients.dashboard.token.url | DAPS_URL | The URL of the DAPS. | |
| micronaut.security.oauth2.clients.dashboard.client-id | CLIENT_ID | The DAPS client id of the certificate used. | |
| logginghouse.token.client.id | DAPS_CLIENT_ID | This is the client id made up of ski:aki atm. | |
| logginghouse.token.keystore.url | CLIENT_KEYSTORE_URL | The URL where the keystore can be found. | |
| logginghouse.token.client.password | CLIENT_KEYSTORE_PASSWORD | The keystore password. | password |

### Connector Config
The Clearing House Dashboard needs a connector to connect with the Broker and other Connectors in the IDS.
The following variables configure this "gateway" connector.

| Property | Environment variable        | Description           | Defaults  |
| ------------- | ------------- |-------------| -----|
| micronaut.http.services.dsc.url | MICRONAUT_HTTP_SERVICES_DSC_URL | The URL of the DSC that this logging house uses to communicate with the data sapce. | |
| logginghouse.dsc.user | LOGGINGHOUSE_DSC_USER | Admin user name of the DSC that this logging house uses to communicate with the data sapce. | admin |
| logginghouse.dsc.password | LOGGINGHOUSE_DSC_PASSWORD | Admin password of the DSC that this logging house uses to communicate with the data sapce. | password |

### Broker Config
| Property | Environment variable        | Description           | Defaults  |
| ------------- | ------------- |-------------| -----|
| logginghouse.broker.url | LOGGINGHOUSE_BROKER_URL | The URL of the data space Broker. | https://broker/infrastructure |
| logginghouse.ignore | LOGGINGHOUSE_IGNORE | A list of URL patterns. A connector with a URL matching one of the listed patterns will be ignored during the Logging House update. |  |

### Configuring IDS Component Links
The UI displays three buttons at the top left. These buttons are used to the Broker, the Vocabulary Provider and the App
Store. The following parameters can be used to configure the three buttons.

| Property | Environment variable        | Description           | Example  |
| ------------- | ------------- |-------------| -----|
| logginghouse.idscomponents.broker | LOGGINGHOUSE_IDSCOMPONENTS_BROKER | The display name for the broker button. | LOGGINGHOUSE_IDSCOMPONENTS_BROKER=Metadata-Broker |
| logginghouse.connectors.brokerurl | LOGGINGHOUSE_IDSCOMPONENTS_BROKERURL | The link to the broker UI. | LOGGINGHOUSE_IDSCOMPONENTS_BROKERURL=https://broker.test.mobilitydataspace.io/connector |
| logginghouse.idscomponents.appstore | LOGGINGHOUSE_IDSCOMPONENTS_APPSTORE | The display name for the app store button. | LOGGINGHOUSE_IDSCOMPONENTS_APPSTORE=AppStore |
| logginghouse.connectors.appstoreurl | LOGGINGHOUSE_IDSCOMPONENTS_APPSTOREURL | The link to the app store UI. | LOGGINGHOUSE_IDSCOMPONENTS_APPSTOREURL=https://drm-appstore.fit.fraunhofer.de/search |
| logginghouse.idscomponents.vocprovider | LOGGINGHOUSE_IDSCOMPONENTS_VOCPROVIDER | The display name for the vocabulary provider button. | LOGGINGHOUSE_IDSCOMPONENTS_VOCPROVIDER=Vocabulary-Provider |
| logginghouse.connectors.vocproviderurl | LOGGINGHOUSE_IDSCOMPONENTS_VOCPROVIDERURL | The link to the vocabulary provider UI. | LOGGINGHOUSE_IDSCOMPONENTS_VOCPROVIDERURL=https://vocol.iais.fraunhofer.de/MobiDS/vocob/searchOnto |

### Finding the DAPS Client Id
You will be provided with a PKCS12 certificate file (.p12 ending) from your Certificate Authority. This file contains
the identifier that has to be used for the DAPS_CLIENT_ID parameter. You can find out the Daps Client Id by issuing the following console command:
```
openssl pkcs12 -in your_certificate.p12 -nodes -passin pass:"password" | openssl x509 -text
```
The ouptut will contain a subject key identifier and an authority key identifier. Similar to this:
```
X509v3 Subject Key Identifier: 
    22:8F:0C:43:DF:A7:F3:0E:B6:82:B1:92:7C:E4:58:68:91:82:97:84
X509v3 Authority Key Identifier: 
    keyid:CB:8C:C7:B6:85:79:A8:23:A6:CB:15:AB:17:50:2F:E6:65:43:5D:E8
```
By combining these two with a colon (:) like <Subject Key Identifier>:<Authority Key Identifier> you get the
DAPS_CLIENT_ID to use in your configuration. For the example above the DAPS_CLIENT_ID would be:
```
22:8F:0C:43:DF:A7:F3:0E:B6:82:B1:92:7C:E4:58:68:91:82:97:84:keyid:CB:8C:C7:B6:85:79:A8:23:A6:CB:15:AB:17:50:2F:E6:65:43:5D:E8
```

### Creating a new release
Every new commit to the main branch creates a new release of the logging house backend.
To create a new release update the project version in the ``pom.xml`` and check-in to the main branch. This will create a new release and publish a new docker container in the container registry.
If you forget to update the project version, the release will fail.