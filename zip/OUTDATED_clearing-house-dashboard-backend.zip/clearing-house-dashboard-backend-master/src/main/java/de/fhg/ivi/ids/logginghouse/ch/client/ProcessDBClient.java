package de.fhg.ivi.ids.logginghouse.ch.client;

import com.mongodb.client.MongoClient;
import de.fhg.ivi.ids.logginghouse.ch.model.Process;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Singleton
public class ProcessDBClient {

    @Inject
    @Named("processdb")
    MongoClient processDB;

    public List<Process> getProcesses() {
        var processes = processDB
                .getDatabase("process")
                .getCollection("processes")
                .find()
                .spliterator();

        return StreamSupport.stream(processes, false)
                .map(doc ->
                        new Process()
                                .setId(doc.getString("id"))
                                .setOwners(doc.getList("owners", String.class)))
                .collect(Collectors.toList());
    }
}
