package de.fhg.ivi.ids.logginghouse.ch.model;

import io.micronaut.core.annotation.Introspected;
import lombok.Data;

import java.util.List;

@Data
@Introspected
public class Process {
    String id;
    List<String> owners;
}
