package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.persistence.Artifact;
import de.fhg.ivi.ids.logginghouse.persistence.ArtifactRepository;
import de.fraunhofer.iais.eis.Representation;
import org.mapstruct.Mapper;

import javax.inject.Inject;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Mapper(componentModel = "jsr330")
public abstract class ArtifactMapper {

    @Inject
    ArtifactRepository artifactRepository;

    Artifact resolveArtifact(String id) {
        if (id == null) {
            return null;
        }
        return artifactRepository.resolveArtifact(URI.create(id));
    }

    Set<Artifact> map(ArrayList<? extends Representation> source) {
        if (source == null) {
            return null;
        }

        return source.stream()
                .map(Representation::getInstance)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .map(representationInstance -> resolveArtifact(representationInstance.getId().toString()))
                .collect(Collectors.toSet());
    }
}
