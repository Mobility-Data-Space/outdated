package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.model.NodeValue;
import de.fhg.ivi.ids.logginghouse.persistence.Connector;
import de.fhg.ivi.ids.logginghouse.persistence.Participant;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "jsr330")
public interface NodeValueMapper {

    List<NodeValue> mapConnectors(Iterable<Connector> connector);

    @Mapping(source="curator.id", target="group")
    @Mapping(target="type", constant = "CONNECTOR")
    @Mapping(source="title", target="name")
    NodeValue map(Connector connector);

    @Mapping(source="id", target="group")
    @Mapping(target="type", constant = "CURATOR")
    NodeValue map(Participant participant);


}
