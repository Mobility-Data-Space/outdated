package de.fhg.ivi.ids.logginghouse.ch;

import lombok.extern.slf4j.Slf4j;

import java.util.Base64;

@Slf4j
public class MessageDecoder {

    public static String decode(String message) {

        if (message == null || message.isBlank() || message.startsWith("{")) {
            return message;
        }

        try {
            return new String(Base64.getDecoder().decode(message));
        } catch (Exception e) {
            log.debug("Message could not be decoded: {}, Message: {}", e.getMessage(), message);
            // Assume message is not encoded and return it as is.
            return message;
        }
    }
}
