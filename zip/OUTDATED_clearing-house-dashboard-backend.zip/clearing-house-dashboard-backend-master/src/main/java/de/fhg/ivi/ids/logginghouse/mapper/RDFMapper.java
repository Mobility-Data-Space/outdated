package de.fhg.ivi.ids.logginghouse.mapper;


import de.fraunhofer.iais.eis.util.RdfResource;
import de.fraunhofer.iais.eis.util.TypedLiteral;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

import java.net.URI;
import java.util.ArrayList;

@Mapper(componentModel = "jsr330")
public interface RDFMapper {

    default String map(ArrayList<? extends TypedLiteral> typedLiterals) {
        return (typedLiterals == null) ? null :
                typedLiterals.stream().map(RdfResource::getValue).findAny().orElse(null);
    }

    default String map(URI uri) {
        return (uri == null) ? null : uri.toString();
    }

    @Named("mapShortId")
    default String mapShortId(URI uri) {
        var id = map(uri);

        if (id == null || id.isBlank()) {
            return id;
        }

        var index = id.lastIndexOf("/");
        if (index < 0) {
            return id;
        }

        return id.substring(index + 1);
    }

}
