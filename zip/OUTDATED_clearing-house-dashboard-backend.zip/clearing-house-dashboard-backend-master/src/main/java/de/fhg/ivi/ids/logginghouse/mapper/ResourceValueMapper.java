package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.LogStatistic;
import de.fhg.ivi.ids.logginghouse.model.ResourceValue;
import de.fhg.ivi.ids.logginghouse.persistence.Resource;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.time.Instant;
import java.util.List;
import java.util.Set;

@Mapper(componentModel = "jsr330", uses = {DataCategoryValueMapper.class, RDFMapper.class})
public interface ResourceValueMapper {

    @Mapping(source = "title", target = "name")
    ResourceValue map(Resource resource);

    List<ResourceValue> map(Set<Resource> resources);

    default Integer map(Instant instant ) {
        if (instant == null)
            return null;
        return Long.valueOf(instant.getEpochSecond()).intValue();
    }

    @Mapping(source = "contract.id", target = "contractId", qualifiedByName = "mapShortId")
    ResourceValue map(LogStatistic source, @MappingTarget ResourceValue resourceValue);

}
