package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.broker.BrokerClient;
import de.fhg.ivi.ids.logginghouse.broker.model.BrokerConnector;
import de.fhg.ivi.ids.logginghouse.broker.model.BrokerResource;
import de.fhg.ivi.ids.logginghouse.mapper.ConnectorMapper;
import de.fhg.ivi.ids.logginghouse.mapper.ResourceMapper;
import de.fhg.ivi.ids.logginghouse.persistence.Connector;
import de.fhg.ivi.ids.logginghouse.persistence.ConnectorRepository;
import de.fhg.ivi.ids.logginghouse.persistence.Resource;
import de.fhg.ivi.ids.logginghouse.persistence.ResourceRepository;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

import static javax.transaction.Transactional.TxType.REQUIRES_NEW;

@Singleton
@Slf4j
public class BrokerUpdateService {

    @Inject
    ResourceRepository resourceRepository;

    @Inject
    ConnectorRepository connectorRepository;

    @Inject
    BrokerClient brokerClient;

    @Inject
    ResourceMapper resourceMapper;

    @Inject
    ConnectorMapper connectorMapper;

    /**
     * Updates Connectors and Resources in the database with data from the Broker.
     */
    @Transactional(REQUIRES_NEW)
    public void update() {
        var resources = brokerClient.getResources().stream()
                .filter(resource -> resource.getConnectorId() != null)
                .collect(
                        Collectors.groupingBy(
                                BrokerResource::getConnectorId,
                                Collectors.mapping(
                                        this::resolve,
                                        Collectors.toList())));

        getConnectorsFromBroker()
                .forEach(connector -> {
                    addResources(connector, resources.get(connector.getId()));
                    connectorRepository.update(connector);
                });
    }

    /**
     * Gets connectors from Broker and maps them to the connectors already present in the database. If a new connector
     * is found at the Broker, that is not already present in the database, it will be created.
     *
     * This method must be called inside a transaction context. It will not open a transaction context itself.
     * An error will be thrown, if called outside a running transaction context.
     *
     * @return the list of mapped, persistent connectors.
     */
    @Transactional(Transactional.TxType.MANDATORY)
    public List<Connector> getConnectorsFromBroker() {
        return brokerClient.getConnectors()
                .stream()
                .map(this::resolve)
                .collect(Collectors.toList());
    }

    private void addResources(Connector connector, List<Resource> r) {
        if (r != null) {
            connector.getResources().addAll(r);
        }
    }

    Connector resolve(BrokerConnector source) {
        return connectorRepository
                .findById(source.getId())
                .map(connector -> connectorMapper.map(source))
                .orElseGet(() -> connectorRepository.save(connectorMapper.map(source)));
    }

    Resource resolve(BrokerResource source) {
        return resourceRepository
                .findById(source.getId())
                .map(resource -> resourceMapper.map(source))
                .orElseGet(() -> resourceRepository.save(resourceMapper.map(source)));
    }

}