package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.time.Instant;
import java.util.Set;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Resource {

    @Id
    @EqualsAndHashCode.Include
    private String id;

    @Nullable
    private String title;

    @Nullable
    private String description;

    @Nullable
    private Instant created;

    @Nullable
    private Instant modified;

    @Nullable
    private String publisher;

    @Nullable
    private String license;

    @Nullable
    private String version;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "resource_datacategories",
            joinColumns = @JoinColumn(name = "resource_id"),
            inverseJoinColumns = @JoinColumn(name = "datacategory_id"))
    private Set<DataCategory> dataCategories;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "resource", cascade = CascadeType.ALL)
    private Set<Artifact> artifacts;

    public void setArtifacts(Set<Artifact> artifacts) {
        artifacts.forEach(artifact -> artifact.setResource(this));
        this.artifacts = artifacts;
    }

}
