package de.fhg.ivi.ids.logginghouse.scheduler;

import de.fhg.ivi.ids.logginghouse.ConnectorUpdateService;
import io.micronaut.context.annotation.Requires;
import io.micronaut.scheduling.annotation.Scheduled;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Requires(property = "logginghouse.connectorsync.enabled", value = "true", defaultValue = "false")
public class ConnectorUpdateScheduler {

    @Inject
    ConnectorUpdateService connectorUpdateService;

    @Scheduled(
            fixedDelay = "${logginghouse.connectorsync.fixeddelay}",
            initialDelay = "${logginghouse.connectorsync.initialdelay}"
    )
    void schedule() {
        connectorUpdateService.update();
    }

}
