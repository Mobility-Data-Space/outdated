package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.ch.ClearingHouseService;
import de.fhg.ivi.ids.logginghouse.ch.model.LogEntry;
import de.fhg.ivi.ids.logginghouse.mapper.ContractMapper;
import de.fhg.ivi.ids.logginghouse.persistence.*;
import de.fraunhofer.iais.eis.ContractAgreement;
import de.fraunhofer.iais.eis.Rule;
import de.fraunhofer.iais.eis.ids.jsonld.Serializer;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.io.IOException;
import java.net.URI;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class ClearingHouseUpdateService {

    @Inject
    ClearingHouseService clearingHouseService;

    @Inject
    ContractRepository contractRepository;

    @Inject
    ArtifactRepository artifactRepository;

    @Inject
    private Serializer serializer;

    @Inject
    ContractMapper contractMapper;

    @Transactional
    public void update() {
        log.info("Update from Clearing House started.");
        var processes = clearingHouseService.getProcesses();
        log.info("Found {} processes.", processes.size());

        processes.stream()
                .flatMap(process -> clearingHouseService.getContract(process.getId()).stream())
                .flatMap(logEntry -> parseContract(logEntry).stream())
                .forEach(this::save);

        log.info("Finished update from Clearing House.");
    }

    void save(ContractAgreement contractAgreement) {
        var exists = contractRepository.existsById(contractAgreement.getId());

        // a contract is never updated
        if (exists) {
            return;
        }

        var artifactIDs = getArtifactIDs(contractAgreement)
                .stream()
                .map(uri -> artifactRepository.resolveArtifact(uri))
                .collect(Collectors.toSet());

        var contract = contractMapper.map(contractAgreement);
        contract.setArtifacts(artifactIDs);

        contractRepository.save(contract);
        log(contract);
    }

    Set<URI> getArtifactIDs(ContractAgreement contract) {
        return contract.getPermission().stream()
                .map(Rule::getTarget)
                .collect(Collectors.toSet());
    }

    Optional<ContractAgreement> parseContract(LogEntry contract) {
        return contract.getPayload()
                .map(part -> {
                    try {
                        return serializer.deserialize(part.getContent(), ContractAgreement.class);
                    } catch (IOException e) {
                        log.warn("Could not deserialize log entry payload of PID {} to ContractAgreement. Message:\n{}",
                                contract.getPid(), part.getContent());
                        return null;
                    }
                });
    }

    private void log(Contract contract) {
        if (log.isDebugEnabled()) {
            String artifacts = contract.getArtifacts().stream()
                    .map(Artifact::getId)
                    .collect(Collectors.joining(","));
            log.debug("Contract {} created. {} -- {} --> {}",
                    contract, contract.getProvider(), artifacts, contract.getConsumer());
        }
    }
}
