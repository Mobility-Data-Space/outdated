package de.fhg.ivi.ids.logginghouse.ch.model;

import lombok.Data;

import java.util.List;
import java.util.Optional;

@Data
public class LogEntry {
    String id;
    String dt_id;
    String pid;
    long ts;
    long tc;
    List<Part> parts;

    public Optional<Part> getIssuerConnector() {
        return getPart("issuer_connector");
    }

    public Optional<Part> getPayload() {
        return getPart("payload");
    }

    Optional<Part> getPart(String name) {
        if (name == null || parts == null || parts.isEmpty()) {
            return Optional.empty();
        }

        return parts.stream()
                .filter(p -> name.equals(p.getName()))
                .findAny();
    }


}
