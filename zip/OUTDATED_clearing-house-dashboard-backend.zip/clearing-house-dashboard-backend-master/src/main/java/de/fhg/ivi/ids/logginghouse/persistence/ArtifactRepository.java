package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.net.URI;

@Repository
public interface ArtifactRepository extends CrudRepository<Artifact, String> {

    default Artifact resolveArtifact(URI uri) {
        var uuid = getUUID(uri);
        return findById(uuid)
                .orElseGet(() -> save(new Artifact().setId(uuid)));
    }

    // Workaround for https://github.com/International-Data-Spaces-Association/DataspaceConnector/issues/971
    private String getUUID(URI uri) {
        var segments = uri.getPath().split("/");
        return segments[segments.length -1];
    }
}
