package de.fhg.ivi.ids.logginghouse.configuration;

import io.micronaut.context.annotation.ConfigurationProperties;
import lombok.Data;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@ConfigurationProperties("logginghouse")
@Data
public class Configuration {

    private Broker broker;

    private DSC dsc;

    private IDSComponents idscomponents;

    private Clearinghouse clearinghouse;

    List<String> ignore = List.of();

    @ConfigurationProperties("idscomponents")
    @Data
    public static class IDSComponents {
        private String broker;
        private String brokerurl;
        private String appstore;
        private String appstoreurl;
        private String vocprovider;
        private String vocproviderurl;
    }

    @ConfigurationProperties("broker")
    @Data
    public static class Broker {
        private String url;
    }

    @ConfigurationProperties("clearinghouse")
    @Data
    public static class Clearinghouse {
        private String url;
    }

    @ConfigurationProperties("dsc")
    @Data
    public static class DSC {
        private String user;
        private String password;
        private String authHeader;

        public String getAuthHeader() {
            if (authHeader == null) {
                authHeader = "Basic " +
                        Base64.getEncoder().encodeToString((user + ":" + password).getBytes(StandardCharsets.UTF_8));
            }
            return authHeader;
        }
    }

}