package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.persistence.Participant;
import de.fhg.ivi.ids.logginghouse.persistence.ParticipantRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import javax.inject.Inject;
import java.net.URI;

@Mapper(componentModel = "jsr330", uses = RDFMapper.class)
public abstract class ParticipantMapper {

    @Inject
    ParticipantRepository participantRepository;

    @Named("resolveParticipant")
    public Participant resolve(URI participantURI) {
        if (participantURI == null) {
            return null;
        }

        return participantRepository.findById(participantURI.toString())
                .map(participant -> update(participantURI, participant))
                .orElseGet(() -> participantRepository.save(map(participantURI)));
    }

    @Mapping(source = "uri", target = "id")
    @Mapping(source = "uri", target = "name")
    abstract Participant map(URI uri);

    @Mapping(source = "uri", target = "id")
    @Mapping(source = "uri", target = "name")
    abstract Participant update(URI uri, @MappingTarget Participant participant);

}
