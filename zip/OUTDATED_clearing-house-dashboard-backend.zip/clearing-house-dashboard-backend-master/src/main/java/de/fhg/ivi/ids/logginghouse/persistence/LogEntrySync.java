package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Used to store the sync state for log entries of PIDs.
 *
 * Stores the last page synced per PID;
 */
@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LogEntrySync {

    @Id
    @EqualsAndHashCode.Include
    String id;

    long page;

}
