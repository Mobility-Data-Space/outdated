package de.fhg.ivi.ids.logginghouse.scheduler;

import de.fhg.ivi.ids.logginghouse.ClearingHouseLogService;
import io.micronaut.context.annotation.Requires;
import io.micronaut.scheduling.annotation.Scheduled;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Requires(property = "logginghouse.logsync.enabled", value = "true", defaultValue = "false")
public class ClearingHouseLogScheduler {

    @Inject
    ClearingHouseLogService clearingHouseLogService;

    @Scheduled(fixedDelay = "${logginghouse.logsync.fixeddelay}", initialDelay = "${logginghouse.logsync.initialdelay}")
    void schedule() {
        clearingHouseLogService.syncAgreements();
    }

}
