package de.fhg.ivi.ids.logginghouse.ch;

import de.fhg.ivi.ids.logginghouse.ch.client.DocumentClient;
import de.fhg.ivi.ids.logginghouse.ch.client.ProcessDBClient;
import de.fhg.ivi.ids.logginghouse.ch.model.LogEntry;
import de.fhg.ivi.ids.logginghouse.ch.model.Part;
import de.fhg.ivi.ids.logginghouse.ch.model.Process;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.List;
import java.util.Optional;

import static de.fhg.ivi.ids.logginghouse.ch.client.DocumentClient.SortOrder.ASC;

@Singleton
@Slf4j
public class ClearingHouseService {

    @Inject
    ProcessDBClient processDBClient;

    @Inject
    DocumentClient documentClient;

    public Optional<LogEntry> getContract(String pid) {
        List<LogEntry> entries;
        try {
            entries = documentClient.getDocuments(pid, 1, 1, ASC);
        } catch (Exception e) {
            log.warn("Exception while getting contract for pid {} - {}", pid, e.getMessage());
            return Optional.empty();
        }

        if (entries == null || entries.isEmpty()) {
            return Optional.empty();
        }

        var contract = entries.get(0);
        decodePayload(contract);
        return Optional.of(contract);
    }

    public List<Process> getProcesses() {
        return processDBClient.getProcesses();
    }

    private void decodePayload(LogEntry e) {
        if (e == null || e.getParts() == null) {
            return;
        }

        e.getParts().stream()
                .filter(p -> "payload".equals(p.getName()))
                .findAny()
                .filter(p -> p.getContent() != null)
                .ifPresent(this::decodePart);
    }

    private void decodePart(Part p) {
        p.setContent(MessageDecoder.decode(p.getContent()));
    }


}
