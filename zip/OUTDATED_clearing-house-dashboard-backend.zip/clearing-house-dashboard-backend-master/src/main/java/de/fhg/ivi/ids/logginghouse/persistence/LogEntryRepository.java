package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.time.Instant;

@Repository
public interface LogEntryRepository extends CrudRepository<LogEntry, String> {

    long countByLogConnectorIdAndIssuerConnectorIdAndPidAndMessageTypeAndTimestampAfterAndTimestampBefore(
            String logConnectorId,
            String issuerConnectorId,
            String pid,
            LogEntry.MessageType type,
            Instant after,
            Instant before
    );

}
