package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import java.net.URI;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Artifact {

    @Id
    @EqualsAndHashCode.Include
    private String id;

    @ToString.Exclude
    @ManyToOne
    private Resource resource;

}
