package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.mapper.ConnectorMapper;
import de.fhg.ivi.ids.logginghouse.mapper.ResourceMapper;
import de.fhg.ivi.ids.logginghouse.persistence.ConnectorRepository;
import de.fhg.ivi.ids.logginghouse.persistence.Resource;
import de.fhg.ivi.ids.logginghouse.persistence.ResourceRepository;
import de.fraunhofer.iais.eis.Connector;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.net.URI;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Singleton
@Slf4j
public class ConnectorUpdateService {

    @Inject
    ConnectorRepository connectorRepository;

    @Inject
    ResourceRepository resourceRepository;

    @Inject
    ConnectorClient connectorClient;

    @Inject
    ConnectorMapper connectorMapper;

    @Inject
    ResourceMapper resourceMapper;

    public void update() {
        log.info("Update from Connectors started.");
        var connectors = connectorRepository.findId();
        log.info("Found {} connectors to sync.", connectors.size());
        connectors.forEach(this::updateConnector);
        log.info("Finished update from Connectors.");
    }

    @Transactional
    public void updateConnector(String id) {
        var url = guessUrl(id);

        log.debug("Get connector self-description from {} for connector with id {}", url, id);

        connectorClient
                .getSelfDescription(url)
                .ifPresent(selfDescription -> {
                    var resources = updateResources(selfDescription);
                    updateConnector(id, selfDescription, resources);
                });
    }

    private String guessUrl(String id) {
        try {
            var url = URI.create(id);

            if (url.getPath().endsWith("/api/ids/data")) {
                return id;
            }

            var sb = new StringBuilder(id);
            if (!id.endsWith("/")) {
                sb.append("/");
            }
            sb.append("api/ids/data");
            return sb.toString();

        } catch (IllegalArgumentException e) {
            return id;
        }
    }

    private void updateConnector(String id, Connector selfDescription, Iterable<Resource> resources) {
        connectorRepository.findById(id)
                .map(connector -> connectorMapper.update(selfDescription, connector))
                .ifPresentOrElse(connector -> {
                            var resourceSet = StreamSupport
                                    .stream(resources.spliterator(), false)
                                    .collect(Collectors.toSet());
                            if (log.isDebugEnabled()) {
                                var res = resourceSet.stream().map(Resource::getId).collect(Collectors.joining());
                                log.debug("Update connector {} with resources {}", id, res);
                            }
                            connector.getResources().addAll(resourceSet);
                            connectorRepository.update(connector);
                        },
                        () -> log.warn("Could not update connector with id {}. Not found or mapping failed.", id));
    }

    private Iterable<Resource> updateResources(Connector selfDescription) {
        var accessURL = selfDescription.getHasDefaultEndpoint().getAccessURL();
        var catalogIds = selfDescription.getResourceCatalog();
        var catalogs = connectorClient.getResourceCatalogs(accessURL, catalogIds);
        var resources = resourceMapper.update(catalogs);
        return resourceRepository.updateAll(resources);
    }

}
