package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

@Repository
public interface DataCategoryRepository extends CrudRepository<DataCategory, String> {

    default DataCategory resolveDataCategory(String category) {
        return findById(category)
                .orElseGet(() -> save(new DataCategory()
                        .setId(category)
                        .setName(category)));
    }
}
