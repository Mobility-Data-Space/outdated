package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Query;
import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface ConnectorRepository extends CrudRepository<Connector, String> {

    List<Connector> findAll();

    List<String> findId();

    List<Connector> findByOwned(boolean owned);

    List<Connector> findByCuratorId(String id);

    @Query("SELECT c FROM Connector c INNER JOIN c.resources rs WHERE rs.id = :id")
    Connector findByResourcesId(String id);

    @Query("SELECT t.id FROM Connector s INNER JOIN s.resources rs, Connector t INNER JOIN t.consumedResources rt " +
            "WHERE s.id = :sourceId AND rs.id = rt.id")
    List<String> findConsumerConnectorIds(String sourceId);

    @Query("SELECT t.id FROM Connector s INNER JOIN s.consumedResources rs, Connector t INNER JOIN t.resources rt " +
            "WHERE s.id = :sourceId AND rs.id = rt.id")
    List<String> findProviderConnectorIds(String sourceId);

}
