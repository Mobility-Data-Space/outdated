package de.fhg.ivi.ids.logginghouse.broker;

import de.fhg.ivi.ids.logginghouse.broker.model.BrokerConnector;
import de.fhg.ivi.ids.logginghouse.broker.model.BrokerResource;
import de.fhg.ivi.ids.logginghouse.configuration.Configuration;
import de.fhg.ivi.ids.logginghouse.dsc.api.MessagesApiClient;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.http.exceptions.HttpStatusException;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.net.URI;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class BrokerClient {

    @Inject
    Configuration config;

    @Inject
    private MessagesApiClient messagesApiClient;

    public Collection<BrokerResource> getResources() {
        String resultStr = sendQueryToBroker(BrokerQueries.RESOURCE_QUERY);

        var resources = parseResources(resultStr);

        if (log.isDebugEnabled()) {
            log.debug("Resources in broker data: {}", resources.stream()
                    .map(BrokerResource::toString)
                    .collect(Collectors.joining()));
        }

        return resources;
    }

    public List<BrokerConnector> getConnectors() {
        String resultStr = sendQueryToBroker(BrokerQueries.CONNECTOR_FULL_QUERY);

        var connectors = parseConnectors(resultStr);

        log.debug("Connector in broker data: " + connectors.stream()
                .map(BrokerConnector::toString)
                .collect(Collectors.joining())
        );

        return connectors;
    }

    private String sendQueryToBroker(String query) {
        log.debug("Sending request to Broker {} {}", config.getBroker().getUrl(), query);

        Object result = handleResponseException(() -> messagesApiClient
                .sendQueryMessage(config.getDsc().getAuthHeader(), URI.create(config.getBroker().getUrl()), query));

        if (result == null || result.toString().isBlank()) {
            throw new HttpStatusException(HttpStatus.BAD_GATEWAY,
                    "Empty connector query result from Broker: " + config.getBroker().getUrl());
        }
        var resultStr = result.toString();

        log.debug("Got result from Broker {}", resultStr);

        return resultStr;
    }


    private Collection<BrokerResource> parseResources(String queryResult) {
        var connectors = queryResult.split("\n");
        checkQueryResult(connectors[0], BrokerQueries.RESOURCE_QUERY_COLUMNS);

        return Arrays.stream(connectors)
                .skip(1)
                .flatMap(line -> parseResourceLine(line).stream())
                .collect(Collectors.groupingBy(
                        BrokerResource::getId,
                        Collectors.reducing(null,
                                Function.identity(),
                                (existingResource, newResource) -> {
                                    if (existingResource == null) {
                                        return newResource;
                                    }
                                    existingResource.getArtifactIds().addAll(newResource.getArtifactIds());
                                    return existingResource;
                                })))
                .values();
    }

    private List<BrokerConnector> parseConnectors(String queryResult) {
        var connectors = queryResult.split("\n");
        checkQueryResult(connectors[0], BrokerQueries.CONNECTOR_QUERY_COLUMNS);
        return Arrays.stream(connectors)
                .skip(1)
                .flatMap(line -> parseConnectorLine(line).stream())
                .collect(Collectors.toList());
    }

    private Optional<BrokerConnector> parseConnectorLine(String line) {
        var parts = line.split("\t");

        if (parts.length != 5) {
            log.warn("Could not parse Broker response to Connector (expected 5 parts): {}", line);
            return Optional.empty();
        }

        return Optional.of(
                new BrokerConnector()
                        .setId(removeIriWrap(parts[0]))
                        .setTitle(removeQuotes(parts[1]))
                        .setUrl(removeIriWrap(parts[2]))
                        .setMaintainer(toURI(removeIriWrap(parts[3])))
                        .setCurator(toURI(removeIriWrap(parts[4])))
        );
    }

    private Optional<BrokerResource> parseResourceLine(String line) {
        var parts = line.split("\t");

        if (parts.length != 10) {
            log.warn("Could not parse Broker response to Resource (expected 10 parts): {}", line);
            return Optional.empty();
        }

        var resource =
                new BrokerResource()
                        .setConnectorId(removeIriWrap(parts[0]))
                        .setId(removeIriWrap(parts[1]))
                        .setTitle(removeQuotes(parts[2]))
                        .setDescription(removeQuotes(parts[3]))
                        .setModified(removeQuotes(parts[4]))
                        .setCreated(removeQuotes(parts[5]))
                        .setPublisher(removeIriWrap(parts[6]))
                        .setLicense(removeIriWrap(parts[7]))
                        .setVersion(removeQuotes(parts[8]));
        resource.getArtifactIds().add(removeIriWrap(parts[9]));
        return Optional.of(resource);
    }

    private void checkQueryResult(String columns, String expectedColumns) {
        if (!columns.equals(expectedColumns)) {
            var message = "Received unexpected result header format from broker " +
                    "(should be '" + expectedColumns + "'), actually: " + columns;
            throw new HttpStatusException(HttpStatus.BAD_GATEWAY, message);
        }
    }

    private String removeIriWrap(String data) {
        if (isEmpty(data)) {
            return data;
        }

        if (!data.startsWith("<") || !data.endsWith(">")) {
            throw new RuntimeException("expected iri to be enclosed in <>, but was: " + data);
        }
        return data.substring(1, data.length() - 1);
    }

    private String removeQuotes(String data) {
        if (isEmpty(data)) {
            return data;
        }

        if (!data.startsWith("\"")) {
            throw new RuntimeException("expected data to be in quotes but was: " + data);
        }
        return data.substring(1, data.indexOf("\"", 1));
    }

    private boolean isEmpty(String s) {
        return s == null || s.isBlank();
    }

    private <R> R handleResponseException(Supplier<R> clientCall) {
        try {
            return clientCall.get();
        } catch (HttpClientResponseException e) {
            throw new HttpStatusException(e.getResponse().getStatus(), e.getResponse().getBody(String.class).orElse(""));
        }
    }

    private URI toURI(String maintainer) {
        return (maintainer == null) ? null : URI.create(maintainer);
    }
}
