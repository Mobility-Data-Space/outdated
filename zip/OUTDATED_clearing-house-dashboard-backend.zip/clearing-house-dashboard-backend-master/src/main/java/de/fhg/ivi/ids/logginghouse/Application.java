package de.fhg.ivi.ids.logginghouse;

import de.fraunhofer.iais.eis.ids.jsonld.Serializer;
import io.micronaut.context.annotation.Factory;
import io.micronaut.context.annotation.Requires;
import io.micronaut.runtime.Micronaut;

import javax.annotation.PostConstruct;
import javax.inject.Singleton;

import org.h2.tools.Server;

import java.sql.SQLException;

@Factory
public class Application {

    public static void main(String[] args) {
        Micronaut.run(Application.class, args);
    }

    @Singleton
    public Serializer getRDFSerializer() {
        return new Serializer();
    }

}
