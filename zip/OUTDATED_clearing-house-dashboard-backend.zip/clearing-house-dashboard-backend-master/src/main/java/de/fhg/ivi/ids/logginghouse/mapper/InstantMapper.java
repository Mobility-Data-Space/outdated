package de.fhg.ivi.ids.logginghouse.mapper;

import org.mapstruct.Mapper;

import javax.xml.datatype.XMLGregorianCalendar;
import java.time.Instant;

@Mapper(componentModel = "jsr330")
public interface InstantMapper {

    default Instant map(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        return Instant.parse(s);
    }

    default Instant map(XMLGregorianCalendar source) {
        if (source == null) {
            return null;
        }
        return source.toGregorianCalendar().toInstant();
    }

}
