package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.api.DataspaceViewApi;
import de.fhg.ivi.ids.logginghouse.configuration.Configuration;
import de.fhg.ivi.ids.logginghouse.mapper.DataCategoryValueMapper;
import de.fhg.ivi.ids.logginghouse.mapper.NodeValueMapper;
import de.fhg.ivi.ids.logginghouse.mapper.ResourceValueMapper;
import de.fhg.ivi.ids.logginghouse.model.*;
import de.fhg.ivi.ids.logginghouse.persistence.*;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.exceptions.HttpStatusException;
import io.micronaut.http.server.types.files.StreamedFile;
import io.micronaut.security.annotation.Secured;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.micronaut.security.rules.SecurityRule.IS_ANONYMOUS;

@Controller
public class LoggingHouseController implements DataspaceViewApi {

    private static final DateTimeFormatter DOWNLOAD_FILE_NAME_FORMATTER = DateTimeFormatter
            .ofPattern("yyyy-MM-dd")
            .withZone(ZoneId.of("Europe/Paris"));

    @Inject
    private ConnectorRepository connectorRepository;

    @Inject
    NodeValueMapper nodeValueMapper;

    @Inject
    DataCategoryValueMapper dataCategoryValueMapper;

    @Inject
    ResourceValueMapper resourceValueMapper;

    @Inject
    Configuration configuration;

    @Inject
    ContractRepository contractRepository;

    @Inject
    ClearingHouseLogService clearingHouseLogService;

    @Override
    @Secured(IS_ANONYMOUS)
    public DataspaceLayoutValue getDataspaceLayout(@Nonnull Optional<Instant> from, @Nonnull Optional<Instant> to) {
        var contracts = contractRepository.find(from.orElse(null), to.orElse(null));

        var contractLinks = contracts.stream()
                .map(contract -> new LinkValue()
                        .setSource(contract.getProvider().getId())
                        .setTarget(contract.getConsumer().getId()))
                .collect(Collectors.toList());

        var connectors = contracts.stream()
                .flatMap(contract -> Stream.of(contract.getProvider(), contract.getConsumer()))
                .collect(Collectors.toSet());

        var connectorNodes = nodeValueMapper.mapConnectors(connectors);
        var participantNodes = connectors.stream()
                .map(Connector::getCurator)
                .filter(Objects::nonNull)
                .map(participant -> nodeValueMapper.map(participant))
                .collect(Collectors.toSet());

        var nodes = Stream
                .concat(connectorNodes.stream(), participantNodes.stream())
                .collect(Collectors.toList());

        var curatorLinks = connectors.parallelStream()
                .filter(connector -> connector.getCurator() != null)
                .map(c -> new LinkValue().setSource(c.getId()).setTarget(c.getCurator().getId()))
                .collect(Collectors.toList());

        var ownConnectors = connectorRepository.findByOwned(true);

        var resourceLinks = ownConnectors.stream()
                .flatMap(connector -> {
                    var consumers = connectorRepository.findConsumerConnectorIds(connector.getId());
                    var providers = connectorRepository.findProviderConnectorIds(connector.getId());
                    var linkTargets = Stream.concat(consumers.stream(), providers.stream())
                            .collect(Collectors.toSet());
                    return linkTargets.stream()
                            .map(targetId -> new LinkValue().setSource(connector.getId()).setTarget(targetId));
                })
                .collect(Collectors.toList());


        var linkValues = Stream.of(curatorLinks.stream(), resourceLinks.stream(), contractLinks.stream())
                .reduce(Stream::concat)
                .orElseGet(Stream::empty)
                .distinct()
                .collect(Collectors.toList());

        return new DataspaceLayoutValue()
                .setLinks(linkValues)
                .setNodes(nodes);
    }

    @Override
    @Secured(IS_ANONYMOUS)
    public Optional<ConnectorValue> getConnectorData(
            String id,
            @Nonnull Optional<Instant> from,
            @Nonnull Optional<Instant> to
    ) {
        var connector = findConnector(id);

        if (connector.getResources() == null) {
            return Optional.of(new ConnectorValue());
        }

        var dataCategories = connector.getResources().stream()
                .flatMap(resource -> resource.getDataCategories().stream())
                .collect(Collectors.toSet());

        var dataCategoryValues = dataCategoryValueMapper.map(dataCategories);
        var resourceValues = resourceValueMapper.map(connector.getResources());

        var result = new ConnectorValue()
                .setDataCategories(dataCategoryValues)
                .setResources(resourceValues);

        return Optional.of(result);
    }

    @Override
    @Secured(IS_ANONYMOUS)
    public Optional<ResourceLinkValue> getLinkData(
            String id,
            String targetId,
            @Nonnull Optional<Instant> from,
            @Nonnull Optional<Instant> to
    ) {
        existsConnector(id, targetId);

        var fromTimestamp = from.orElse(null);
        var toTimestamp = to.orElse(null);
        var outgoing = getConsumedArtifact(id, targetId, fromTimestamp, toTimestamp);
        var incoming = getConsumedArtifact(targetId, id, fromTimestamp, toTimestamp);

        var result = new ResourceLinkValue().setIncoming(incoming).setOutgoing(outgoing);

        return Optional.of(result);
    }

    @Get("/download")
    @Produces({"text/csv"})
    @Secured(IS_ANONYMOUS)
    public StreamedFile download(@Nonnull Instant from, @Nonnull Instant to) {
        var filename = getDownloadFileName(from, to);

        var stats = clearingHouseLogService.participantStatistics(from, to);

        var resultString = stats.stream()
                .map(stat -> "\n"
                        + stat.getContract().getProvider().getId() + ","
                        + stat.getContract().getConsumer().getId() + ","
                        + stat.getContract().getId() + ","
                        + getResource(stat.getContract()).map(Resource::getTitle).orElse("") + ","
                        + stat.getRequestsSent() + ","
                        + stat.getRequestsReceived() + ","
                        + stat.getResponsesSent() + ","
                        + stat.getResponsesReceived())
                .collect(Collectors.joining());

        var header = "Provider_id,Consumer_id,Contract_id,Resource_Title,Requests_Sent,Requests_Received,Responses_Sent,Responses_Received";

        InputStream inputStream = new ByteArrayInputStream((header + resultString).getBytes(StandardCharsets.UTF_8));
        return new StreamedFile(inputStream, new MediaType("text/csv")).attach(filename);
    }

    static String getDownloadFileName(Instant from, Instant to) {
        return "logs_" +
                DOWNLOAD_FILE_NAME_FORMATTER.format(from) +
                "_" +
                DOWNLOAD_FILE_NAME_FORMATTER.format(to) +
                ".csv";
    }

    private Optional<Resource> getResource(Contract contract) {
        return contract.getArtifacts().stream().findAny().map(Artifact::getResource);
    }

    @Override
    @Secured(IS_ANONYMOUS)
    public ConfigValue getConfig() {
        List<AppValue> idsApps = new ArrayList<>();

        if (configuration.getIdscomponents() == null)
            return new ConfigValue();

        idsApps.add(new AppValue()
                .setName(configuration.getIdscomponents().getBroker())
                .setUrl(configuration.getIdscomponents().getBrokerurl()));
        idsApps.add(new AppValue()
                .setName(configuration.getIdscomponents().getVocprovider())
                .setUrl(configuration.getIdscomponents().getVocproviderurl()));
        idsApps.add(new AppValue()
                .setName(configuration.getIdscomponents().getAppstore())
                .setUrl(configuration.getIdscomponents().getAppstoreurl()));

        return new ConfigValue().setApplications(idsApps);
    }

    private Connector findConnector(String id) {
        return connectorRepository.findById(id)
                .orElseThrow(() -> new HttpStatusException(HttpStatus.NOT_FOUND,
                        "A connector with id " + id + " could not be found."));
    }

    private void existsConnector(String... ids) {
        for (String id : ids) {
            if (!connectorRepository.existsById(id)) {
                throw new HttpStatusException(HttpStatus.NOT_FOUND,
                        "A connector with id " + id + " could not be found.");
            }
        }
    }

    private List<ResourceValue> getConsumedArtifact(String sourceId, String targetId, Instant from, Instant to) {
        return contractRepository.findByProviderIdAndConsumerId(sourceId, targetId)
                .stream()
                .flatMap(contract -> contract.getArtifacts().stream().map(artifact -> {
                            var resourceValue = getResourceValue(artifact);
                            var logStatistic = clearingHouseLogService.getLogStatistic(contract, from, to);
                            resourceValueMapper.map(logStatistic, resourceValue);
                            return resourceValue;
                        }
                ))
                .collect(Collectors.toList());
    }

    private ResourceValue getResourceValue(Artifact artifact) {
        var resource = artifact.getResource();
        if (resource == null) {
            return new ResourceValue().setName(artifact.getId());
        } else {
            return resourceValueMapper.map(resource);
        }
    }

}
