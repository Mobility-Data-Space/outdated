package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.broker.model.BrokerConnector;
import de.fhg.ivi.ids.logginghouse.persistence.Connector;
import de.fhg.ivi.ids.logginghouse.persistence.ConnectorRepository;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import javax.inject.Inject;
import java.net.URI;

@Mapper(componentModel = "jsr330",
        uses = {RDFMapper.class, ParticipantMapper.class, ResourceMapper.class})
public abstract class ConnectorMapper {

    @Inject
    ConnectorRepository connectorRepository;

    @Mapping(source = "connector.hasDefaultEndpoint.accessURL", target = "accessUrl")
    @Mapping(source = "connector.maintainer", target = "maintainer", qualifiedByName = "resolveParticipant")
    @Mapping(source = "connector.curator", target = "curator", qualifiedByName = "resolveParticipant")
    public abstract Connector update(de.fraunhofer.iais.eis.Connector connector, @MappingTarget Connector connectorEntity);

    @AfterMapping
    void fixParticipantDuplicates(@MappingTarget Connector connector) {
        if (connector.getCurator() != null && connector.getMaintainer() != null
                && connector.getCurator().getId().equals(connector.getMaintainer().getId())
                && connector.getCurator() != connector.getMaintainer()) {
            connector.setMaintainer(connector.getCurator());
        }
    }

    public Connector map(URI uri) {
        var id = uri.toString();
        return connectorRepository
                .findById(id)
                .orElseGet(() -> connectorRepository.save(new Connector().setId(id)));
    }

    @Mapping(source = "maintainer", target = "maintainer", qualifiedByName = "resolveParticipant")
    @Mapping(source = "curator", target = "curator", qualifiedByName = "resolveParticipant")
    public abstract Connector map(BrokerConnector source);
}