package de.fhg.ivi.ids.logginghouse.broker.model;

import lombok.Data;

import java.net.URI;

@Data
public class BrokerConnector {
    String id;
    String title;
    String url;
    URI maintainer;
    URI curator;
}