package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface ResourceRepository extends CrudRepository<Resource, String> {

    List<Resource> findAll();

    List<Resource> findByPublisher(String id);

}
