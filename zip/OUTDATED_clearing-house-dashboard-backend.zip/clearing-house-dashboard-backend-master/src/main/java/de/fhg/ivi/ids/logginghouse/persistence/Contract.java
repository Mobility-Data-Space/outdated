package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.net.URI;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Contract {

    @Id
    @EqualsAndHashCode.Include
    private URI id;

    @ManyToOne(fetch = FetchType.EAGER)
    Connector provider;

    @ManyToOne(fetch = FetchType.EAGER)
    Connector consumer;

    Instant contractStart;

    Instant contractEnd;

    Instant contractDate;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "contract_artifacts",
            joinColumns = @JoinColumn(name = "contract_id"),
            inverseJoinColumns = @JoinColumn(name = "artifact_id"))
    Set<Artifact> artifacts = new HashSet<>();

}
