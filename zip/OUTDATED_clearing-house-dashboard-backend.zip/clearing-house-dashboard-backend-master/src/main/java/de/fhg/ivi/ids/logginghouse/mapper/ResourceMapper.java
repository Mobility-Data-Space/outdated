package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.broker.model.BrokerResource;
import de.fhg.ivi.ids.logginghouse.persistence.DataCategory;
import de.fhg.ivi.ids.logginghouse.persistence.DataCategoryRepository;
import de.fhg.ivi.ids.logginghouse.persistence.Resource;
import de.fhg.ivi.ids.logginghouse.persistence.ResourceRepository;
import de.fraunhofer.iais.eis.ResourceCatalog;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import javax.inject.Inject;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Mapper(componentModel = "jsr330", uses = {RDFMapper.class, InstantMapper.class, ArtifactMapper.class})
public abstract class ResourceMapper {

    static final String DATA_CATEGORY_KEY = "https://w3id.org/mobids/DataCategory";

    @Inject
    private ResourceRepository resourceRepository;

    @Inject
    private DataCategoryRepository dataCategoryRepository;

    public Resource resolve(de.fraunhofer.iais.eis.Resource resource) {
        return resourceRepository
                .findById(resource.getId().toString())
                .map(resourceEntity -> update(resource, resourceEntity))
                .orElseGet(() -> resourceRepository.save(map(resource)));
    }

    public abstract Resource map(Resource source, @MappingTarget Resource target);

    @Mapping(source = "properties", target = "dataCategories")
    @Mapping(source = "representation", target = "artifacts" )
    @Mapping(source = "standardLicense", target = "license")
    abstract Resource map(de.fraunhofer.iais.eis.Resource resource);

    @Mapping(source = "properties", target = "dataCategories")
    @Mapping(source = "representation", target = "artifacts")
    abstract Resource update(de.fraunhofer.iais.eis.Resource resource, @MappingTarget Resource resourceEntity);

    @Mapping(source = "artifactIds", target = "artifacts")
    public abstract Resource map(BrokerResource source);

    public Set<Resource> update(List<ResourceCatalog> catalog) {
        return catalogToResourceSet(catalog, ResourceCatalog::getOfferedResource, this::resolve);
    }

    Set<Resource> catalogToResourceSet(List<ResourceCatalog> catalog,
                                       Function<ResourceCatalog, List<? extends de.fraunhofer.iais.eis.Resource>> applyOnCatalog,
                                       Function<de.fraunhofer.iais.eis.Resource, Resource> applyOnResource) {
        return catalog.stream()
                .map(applyOnCatalog)
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .map(applyOnResource)
                .collect(Collectors.toSet());
    }

    Set<DataCategory> map(Map<String, Object> properties) {
        if (properties == null) {
            return Set.of();
        }

        return properties.entrySet().stream()
                .filter(entry -> DATA_CATEGORY_KEY.equals(entry.getKey()))
                .map(entry -> {
                    if (entry.getValue() instanceof Map) {
                        //noinspection rawtypes
                        return resolve(String.valueOf(((Map) entry.getValue()).get("@value")));
                    }
                    return resolve(entry.getValue().toString());
                })
                .collect(Collectors.toSet());
    }

    private DataCategory resolve(String category) {
        if (category == null) {
            return null;
        }

        return dataCategoryRepository.resolveDataCategory(category);
    }
}
