package de.fhg.ivi.ids.logginghouse.broker.model;

import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class BrokerResource {
    String id;
    String connectorId;
    String title;
    String description;
    String created;
    String modified;
    String publisher;
    String license;
    String version;
    Set<String> artifactIds = new HashSet<>();
}
