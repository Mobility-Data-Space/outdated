package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.persistence.Contract;
import de.fraunhofer.iais.eis.ContractAgreement;
import org.mapstruct.Mapper;

@Mapper(componentModel = "jsr330", uses = { InstantMapper.class, ConnectorMapper.class })
public interface ContractMapper {

    Contract map(ContractAgreement contractAgreement);

}
