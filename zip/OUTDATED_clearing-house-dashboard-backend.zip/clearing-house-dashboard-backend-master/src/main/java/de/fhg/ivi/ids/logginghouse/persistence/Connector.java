package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
public class Connector {

    @Id
    private String id;

    private String accessUrl;

    private String title;

    boolean owned = false;

    @Nullable
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    private Participant curator;

    @ManyToOne(fetch = FetchType.EAGER)
    private Participant maintainer;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(
            name = "connector_resources",
            joinColumns = @JoinColumn(name = "connector_id"),
            inverseJoinColumns = @JoinColumn(name = "resource_id"))
    private Set<Resource> resources = new HashSet<>();

    @JoinTable(
            name = "connector_consumed_resources",
            joinColumns = @JoinColumn(name = "connector_id"),
            inverseJoinColumns = @JoinColumn(name = "resource_id"))
    @ManyToMany(fetch = FetchType.EAGER)
    private Set<Resource> consumedResources = new HashSet<>();
}
