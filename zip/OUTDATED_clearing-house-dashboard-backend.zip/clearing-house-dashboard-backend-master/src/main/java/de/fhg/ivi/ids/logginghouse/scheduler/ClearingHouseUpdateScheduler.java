package de.fhg.ivi.ids.logginghouse.scheduler;

import de.fhg.ivi.ids.logginghouse.ClearingHouseUpdateService;
import io.micronaut.context.annotation.Requires;
import io.micronaut.scheduling.annotation.Scheduled;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Requires(property = "logginghouse.update.enabled", value = "true", defaultValue = "false")
public class ClearingHouseUpdateScheduler {

    @Inject
    ClearingHouseUpdateService clearingHouseUpdateService;

    @Scheduled(fixedDelay = "${logginghouse.update.fixeddelay}", initialDelay = "${logginghouse.update.initialdelay}")
    void schedule() {
        clearingHouseUpdateService.update();
    }

}
