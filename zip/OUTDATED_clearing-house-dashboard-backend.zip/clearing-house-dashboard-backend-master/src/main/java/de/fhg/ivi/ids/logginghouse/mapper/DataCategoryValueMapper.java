package de.fhg.ivi.ids.logginghouse.mapper;

import de.fhg.ivi.ids.logginghouse.model.DataCategoryValue;
import de.fhg.ivi.ids.logginghouse.persistence.DataCategory;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "jsr330")
public interface DataCategoryValueMapper {

    DataCategoryValue map(DataCategory dataCategory);

    List<DataCategoryValue> map(Iterable<DataCategory> dataCategory);

    @Mapping(source = "id", target = "value")
    List<String> mapIds(Iterable<DataCategory> dataCategory);

    default String mapId(DataCategory dataCategory) {
        return dataCategory.getId();
    }
}
