package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.configuration.Configuration;
import de.fhg.ivi.ids.logginghouse.dsc.api.MessagesApiClient;
import de.fraunhofer.iais.eis.Connector;
import de.fraunhofer.iais.eis.ResourceCatalog;
import de.fraunhofer.iais.eis.ids.jsonld.Serializer;
import io.micronaut.http.client.exceptions.HttpClientException;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class ConnectorClient {

    @Inject
    private Configuration config;

    @Inject
    private MessagesApiClient messagesApiClient;

    @Inject
    private Serializer serializer;

    public Optional<Connector> getSelfDescription(String connectorUrl) {
        return sendRequest(URI.create(connectorUrl), config.getDsc().getAuthHeader(), Optional.empty())
                .filter(response -> !response.isBlank())
                .flatMap(response -> deserialize(response, Connector.class));
    }

    public List<ResourceCatalog> getResourceCatalogs(URI connectorURL, List<? extends ResourceCatalog> catalogs) {
        if (connectorURL == null || catalogs == null) {
            return List.of();
        }

        return catalogs.stream()
                .map(catalog -> Optional.of(catalog.getId()))
                .flatMap(catalogId -> sendRequest(connectorURL, config.getDsc().getAuthHeader(), catalogId).stream())
                .flatMap(catalog -> deserialize(catalog, ResourceCatalog.class).stream())
                .collect(Collectors.toList());
    }

    Optional<String> sendRequest(URI connectorURL, String auth, Optional<URI> catalogId) {
        try {
            return Optional.of(messagesApiClient.sendMessage3(auth, connectorURL, catalogId));
        } catch (HttpClientException e) {
            log.warn("Error sending request{} to {}: {}",
                    catalogId.map(uri -> " for " + uri).orElse(""),
                    connectorURL,
                    e.getMessage());
            return Optional.empty();
        }
    }

    private <T> Optional<T> deserialize(String result, Class<T> clazz) {
        try {
            return Optional.of(serializer.deserialize(result, clazz));
        } catch (IOException e) {
            log.warn("Could not deserialize self description: {}", result);
            return Optional.empty();
        }
    }
}
