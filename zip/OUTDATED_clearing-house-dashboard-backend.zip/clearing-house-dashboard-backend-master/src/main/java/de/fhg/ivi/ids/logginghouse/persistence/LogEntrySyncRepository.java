package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

@Repository
public interface LogEntrySyncRepository extends CrudRepository<LogEntrySync, String> {
}
