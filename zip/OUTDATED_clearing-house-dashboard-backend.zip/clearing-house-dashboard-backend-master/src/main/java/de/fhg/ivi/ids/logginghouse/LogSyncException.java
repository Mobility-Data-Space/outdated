package de.fhg.ivi.ids.logginghouse;

public class LogSyncException extends Exception {

    public LogSyncException(String message, Throwable cause) {
        super(message, cause);
    }
}
