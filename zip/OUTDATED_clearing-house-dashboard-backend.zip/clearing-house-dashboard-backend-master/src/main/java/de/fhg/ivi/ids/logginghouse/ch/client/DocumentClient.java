package de.fhg.ivi.ids.logginghouse.ch.client;

import de.fhg.ivi.ids.logginghouse.ch.model.LogEntry;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.http.client.annotation.Client;

import java.util.List;

@Client(value = "documentapi", path = "/doc", errorType = String.class)
public interface DocumentClient {

    enum SortOrder {
        ASC, DESC
    }

    @Get("/{pid}")
    List<LogEntry> getDocuments(@PathVariable String pid,
                                @QueryValue("page") long page,
                                @QueryValue("size") int size,
                                @QueryValue("sort") SortOrder sort);

    @Get("/{pid}")
    List<LogEntry> getDocuments(@PathVariable String pid);


}
