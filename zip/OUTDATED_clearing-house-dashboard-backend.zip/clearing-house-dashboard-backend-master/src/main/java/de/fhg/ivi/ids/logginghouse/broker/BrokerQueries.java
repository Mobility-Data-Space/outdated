package de.fhg.ivi.ids.logginghouse.broker;

interface BrokerQueries {

    String RESOURCE_QUERY_COLUMNS = "?connectorid\t" +
            "?resourceid\t" +
            "?title\t" +
            "?description\t" +
            "?res_modified\t" +
            "?res_created\t" +
            "?res_publisher\t" +
            "?res_license\t" +
            "?res_version\t" +
            "?artifactid";

    String RESOURCE_QUERY =
            "PREFIX ids: <https://w3id.org/idsa/core/>\n" +
                    "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n" +
                    "SELECT " + RESOURCE_QUERY_COLUMNS + "\n" +
                    "WHERE { GRAPH ?g {\n" +
                    "?connector owl:sameAs ?connectorid .\n" +
                    "?connector ids:resourceCatalog ?catalog .\n" +
                    "?catalog ids:offeredResource ?resource .\n" +
                    "?resource owl:sameAs ?resourceid .\n" +
                    "OPTIONAL {?resource ids:title ?title . }\n" +
                    "OPTIONAL {?resource ids:description ?description . }\n" +
                    "OPTIONAL {?resource ids:modified ?res_modified . }\n" +
                    "OPTIONAL {?resource ids:created ?res_created . }\n" +
                    "OPTIONAL {?resource ids:publisher ?res_publisher . }\n" +
                    "OPTIONAL {?resource ids:standardLicense ?res_license . }\n" +
                    "OPTIONAL {?resource ids:version ?res_version . }\n" +
                    "?resource ids:representation ?representation .\n" +
                    "?representation ids:instance ?instance .\n" +
                    "?instance owl:sameAs ?artifactid .\n" +
                    "}}";

    String CONNECTOR_QUERY_COLUMNS = "?original\t?title\t?url\t?maintainer\t?curator";

    String CONNECTOR_FULL_QUERY = "PREFIX ids: <https://w3id.org/idsa/core/>\n" +
            "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n" +
            "SELECT " + CONNECTOR_QUERY_COLUMNS + "\n" +
            "WHERE { GRAPH ?g {\n" +
            "?connector ids:hasDefaultEndpoint ?endpoint .\n" +
            "?endpoint ids:accessURL ?url .\n" +
            "?connector owl:sameAs ?original . \n" +
            "?connector ids:title ?title .\n" +
            "?connector ids:maintainer ?maintainer .\n" +
            "OPTIONAL {?connector ids:curator ?curator . }\n" +
            "OPTIONAL {?connector ids:operator ?operator . }\n" +
            "}" +
            "}";
}
