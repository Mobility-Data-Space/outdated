package de.fhg.ivi.ids.logginghouse.ch.model;

import lombok.Data;

@Data
public class Part {
    String name;
    String content;
}
