package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Join;
import io.micronaut.data.annotation.Query;
import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.net.URI;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface ContractRepository extends CrudRepository<Contract, URI> {

    @Join(value = "artifacts.resource", type = Join.Type.LEFT_FETCH)
    List<Contract> findAll();

    List<Contract> findByProviderId(String providerId);

    List<Contract> findByConsumerId(String consumerId);

    List<Contract> findByProviderIdAndConsumerId(String consumerId, String providerId);

    @Join(value = "artifacts.resource", type = Join.Type.LEFT_FETCH)
    List<Contract> findByContractEndAfterAndContractStartBefore(Instant from, Instant to);

    @Join(value = "artifacts.resource", type = Join.Type.LEFT_FETCH)
    List<Contract> findByContractEndAfter(Instant from);

    @Join(value = "artifacts.resource", type = Join.Type.LEFT_FETCH)
    List<Contract> findByContractStartBefore(Instant to);

    List<URI> findId();

    default List<Contract> find(Instant from, Instant to) {
        if (from != null && to != null) {
            return this.findByContractEndAfterAndContractStartBefore(from, to);
        } else if (from != null) {
            return this.findByContractEndAfter(from);
        } else if (to != null) {
            return this.findByContractStartBefore(to);
        } else {
            return this.findAll();
        }
    }

}
