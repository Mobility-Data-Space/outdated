package de.fhg.ivi.ids.logginghouse.persistence;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import java.time.Instant;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LogEntry {

    public enum MessageType {
        REQUEST, RESPONSE
    }

    @Id
    @EqualsAndHashCode.Include
    private String id;

    String logConnectorId;

    String recipientConnectorId;

    String issuerConnectorId;

    String pid;

    @Enumerated(EnumType.ORDINAL)
    MessageType messageType;

    String messageId;

    String correlationMessageId;

    Instant timestamp;
}
