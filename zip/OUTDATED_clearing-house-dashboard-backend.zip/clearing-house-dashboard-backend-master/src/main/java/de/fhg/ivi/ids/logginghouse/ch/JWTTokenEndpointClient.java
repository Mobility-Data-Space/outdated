package de.fhg.ivi.ids.logginghouse.ch;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.micronaut.context.BeanContext;
import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Value;
import io.micronaut.core.annotation.NonNull;
import io.micronaut.http.MutableHttpRequest;
import io.micronaut.http.client.HttpClientConfiguration;
import io.micronaut.security.oauth2.endpoint.AuthenticationMethod;
import io.micronaut.security.oauth2.endpoint.token.request.DefaultTokenEndpointClient;
import io.micronaut.security.oauth2.endpoint.token.request.TokenEndpointClient;
import io.micronaut.security.oauth2.endpoint.token.request.context.TokenRequestContext;
import io.micronaut.security.oauth2.endpoint.token.response.TokenResponse;
import io.micronaut.security.oauth2.grants.SecureGrantMap;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;
import java.io.IOException;
import java.net.URL;
import java.security.*;
import java.security.cert.CertificateException;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;

@Singleton
@Replaces(DefaultTokenEndpointClient.class)
@Slf4j
public class JWTTokenEndpointClient extends DefaultTokenEndpointClient implements TokenEndpointClient {

    @Value("${logginghouse.token.client.id}")
    private String clientId;

    @Value("${logginghouse.token.client.password}")
    private String clientPassword;

    @Value("${logginghouse.token.keystore.url}")
    private String keystoreURL;

    public JWTTokenEndpointClient(BeanContext beanContext, HttpClientConfiguration defaultClientConfiguration) {
        super(beanContext, defaultClientConfiguration);
    }

    @Override
    protected <G, R extends TokenResponse> void secureRequest(@NonNull MutableHttpRequest<G> request, TokenRequestContext<G, R> requestContext) {
        var authMethodsSupported = requestContext.getEndpoint()
                .getSupportedAuthenticationMethods()
                .orElseGet(() -> Collections.singletonList(AuthenticationMethod.CLIENT_SECRET_BASIC));
        if (authMethodsSupported.contains(AuthenticationMethod.CLIENT_SECRET_JWT)) {
            log.debug("Using client_secret_jwt authentication for {}", clientId);

            try {
                Key privateKey = getPrivateKey();

                var jwtb = Jwts.builder()
                        .setIssuer(clientId)
                        .setSubject(clientId)
                        .claim("@context", "https://w3id.org/idsa/contexts/context.jsonld")
                        .claim("@type", "ids:DatRequestToken")
                        .setExpiration(Date.from(Instant.now().plusSeconds(3600)))
                        .setIssuedAt(Date.from(Instant.now().minusSeconds(10)))
                        .setAudience("idsc:IDS_CONNECTORS_ALL")
                        .setNotBefore(Date.from(Instant.now().minusSeconds(10)));
                request.getBody().ifPresent(body -> {
                    var b = (SecureGrantMap) body;
                    b.put("client_assertion", jwtb.signWith(SignatureAlgorithm.RS256, privateKey).compact());
                    b.put("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer");
                    b.put("scope", "idsc:IDS_CONNECTOR_ATTRIBUTES_ALL");
                });
                log.debug("JWT created.");
            } catch (Exception e) {
                log.error("Could not create JWT for token request: " + e.getMessage());
            }
        } else {
            super.secureRequest(request, requestContext);
        }
    }

    Key privateKey;

    private Key getPrivateKey() throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException {
        if (privateKey == null) {
            var identityStore = KeyStore.getInstance(KeyStore.getDefaultType());
            try (var inStream = new URL(keystoreURL).openStream()) {
                identityStore.load(inStream, clientPassword.toCharArray());
            }
            privateKey = identityStore.getKey("1", clientPassword.toCharArray());
        }
        return privateKey;
    }
}
