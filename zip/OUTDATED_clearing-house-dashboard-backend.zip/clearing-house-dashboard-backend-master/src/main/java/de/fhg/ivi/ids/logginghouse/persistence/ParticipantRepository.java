package de.fhg.ivi.ids.logginghouse.persistence;

import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface ParticipantRepository extends CrudRepository<Participant, String> {

    List<String> findId();

    List<Participant> findAll();

}
