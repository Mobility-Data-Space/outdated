package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.ch.MessageDecoder;
import de.fhg.ivi.ids.logginghouse.ch.client.DocumentClient;
import de.fhg.ivi.ids.logginghouse.ch.model.LogEntry;
import de.fhg.ivi.ids.logginghouse.ch.model.Part;
import de.fhg.ivi.ids.logginghouse.mapper.InstantMapper;
import de.fhg.ivi.ids.logginghouse.persistence.*;
import de.fhg.ivi.ids.logginghouse.persistence.LogEntry.MessageType;
import de.fraunhofer.iais.eis.Message;
import de.fraunhofer.iais.eis.RequestMessage;
import de.fraunhofer.iais.eis.ResponseMessage;
import de.fraunhofer.iais.eis.ids.jsonld.Serializer;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.io.IOException;
import java.net.URI;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.*;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class ClearingHouseLogService {

    @Inject
    DocumentClient documentClient;

    @Inject
    Serializer serializer;

    @Inject
    LogEntryRepository logEntryRepository;

    @Inject
    InstantMapper instantMapper;

    @Inject
    ContractRepository contractRepository;

    @Inject
    LogEntrySyncRepository logEntrySyncRepository;

    private final DateTimeFormatter logTimeFormatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
            .withLocale(Locale.GERMANY)
            .withZone(ZoneId.from(ZoneOffset.UTC));

    public List<LogStatistic> participantStatistics(Instant from, Instant to) {
        return contractRepository.find(from, to).stream()
                .map(contract -> getLogStatistic(contract, from, to))
                .collect(Collectors.toList());
    }

    public LogStatistic getLogStatistic(Contract contract, Instant from, Instant to) {
        var fromTimestamp = (from == null) ? Instant.ofEpochSecond(953725969) : from;
        var toTimestamp = (to == null) ? Instant.now() : to;

        return getPidFromAgreementId(contract.getId()).map(pid -> {
            var consumer = contract.getConsumer();
            var provider = contract.getProvider();

            var requestsSent =
                    logEntryRepository.countByLogConnectorIdAndIssuerConnectorIdAndPidAndMessageTypeAndTimestampAfterAndTimestampBefore(
                            consumer.getId(),
                            consumer.getId(),
                            pid,
                            MessageType.REQUEST,
                            fromTimestamp,
                            toTimestamp
                    );

            var requestsReceived =
                    logEntryRepository.countByLogConnectorIdAndIssuerConnectorIdAndPidAndMessageTypeAndTimestampAfterAndTimestampBefore(
                            provider.getId(),
                            consumer.getId(),
                            pid,
                            MessageType.REQUEST,
                            fromTimestamp,
                            toTimestamp
                    );

            var responsesSent =
                    logEntryRepository.countByLogConnectorIdAndIssuerConnectorIdAndPidAndMessageTypeAndTimestampAfterAndTimestampBefore(
                            provider.getId(),
                            provider.getId(),
                            pid,
                            MessageType.RESPONSE,
                            fromTimestamp,
                            toTimestamp
                    );

            var responsesReceived =
                    logEntryRepository.countByLogConnectorIdAndIssuerConnectorIdAndPidAndMessageTypeAndTimestampAfterAndTimestampBefore(
                            consumer.getId(),
                            provider.getId(),
                            pid,
                            MessageType.RESPONSE,
                            fromTimestamp,
                            toTimestamp
                    );

            return new LogStatistic()
                    .setContract(contract)
                    .setRequestsSent(requestsSent)
                    .setRequestsReceived(requestsReceived)
                    .setResponsesSent(responsesSent)
                    .setResponsesReceived(responsesReceived);
        }).orElse(null);
    }


    public void syncAgreements() {
        log.info("Started syncing logs for all agreements from Clearing House.");
        contractRepository.findId().forEach(this::syncAgreement);
        log.info("Finished syncing logs for all agreements from Clearing House.");
    }

    public void syncAgreement(URI id) {
        getPidFromAgreementId(id)
                .ifPresentOrElse(
                        pid -> {
                            try {
                                syncPID(pid, getLastSyncedPage(pid));
                            } catch (LogSyncException e) {
                                log.warn(e.getMessage());
                            }
                        },
                        () -> log.info("Invalid Agreement Id will not be synced {}.", id)
                );
    }

    public void syncPID(String pid, long page) throws LogSyncException {
        log.info("Started syncing logs for PID {} from Clearing House.", pid);

        var pageSize = 50;
        var sortOrder = DocumentClient.SortOrder.ASC;

        // there is a bug in the clearing house document api. If page number exceeds the last page then the contents of
        // the last page will be returned. Therefore the document api will never stop returning documents. The only way for a client
        // to realize that it has reached the last page is to compare the documents returned with the previous page.
        // If they are equal, then the last page has been reached.
        List<LogEntry> oldEntries = null;

        while (page != -1) {
            var entries = getDocuments(pid, page, pageSize, sortOrder);

            if (isAlreadyBehindLastPage(entries, oldEntries)) {
                break;
            }

            oldEntries = entries;

            var logEntities = entries.stream()
                    .filter(e -> e.getPayload().isPresent())
                    .flatMap(e -> parseMessage(MessageDecoder.decode(e.getPayload().get().getContent()))
                            .flatMap(message -> map(message, e))
                            .stream())
                    .collect(Collectors.toList());

            var logEntrySync = new LogEntrySync()
                    .setId(pid)
                    .setPage(page);

            if (log.isDebugEnabled()) {
                var size = logEntities.size();
                var minTime = (size == 0) ? null : logEntities.get(0).getTimestamp();
                var maxTime = (size == 0) ? null : logEntities.get(logEntities.size() - 1).getTimestamp();
                log.debug("Storing {} logs for pid {} from {} to {}", size, pid,
                        (minTime == null) ? "not set" : logTimeFormatter.format(minTime),
                        (maxTime == null) ? "not set" : logTimeFormatter.format(maxTime));
            }

            store(logEntities, logEntrySync);

            if (entries.isEmpty() || entries.size() < pageSize) {
                page = -1;
            } else {
                page++;
            }
        }
        log.info("Finished syncing logs for PID {} from Clearing House.", pid);
    }

    private List<LogEntry> getDocuments(String pid, long page, int pageSize, DocumentClient.SortOrder sortOrder)
            throws LogSyncException {
        try {
            return documentClient.getDocuments(pid, page, pageSize, sortOrder);
        } catch (HttpClientResponseException e) {
            var message = String.format("Failed sync logs for PID %s at page %d (size %d). Error from Clearing House Document API: %s",
                    pid, page, pageSize, e.getMessage());
            throw new LogSyncException(message, e);
        }
    }

    boolean isAlreadyBehindLastPage(List<LogEntry> entries, List<LogEntry> oldEntries) {
        if (entries == null || entries.isEmpty()) {
            return true;
        }

        var size = entries.size();
        if (oldEntries == null || oldEntries.size() != size) {
            return false;
        }

        for (int i = 0; i < size; i++) {
            if (!entries.get(i).getId().equals(oldEntries.get(i).getId())) {
                return false;
            }
        }

        return true;
    }

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    void store(List<de.fhg.ivi.ids.logginghouse.persistence.LogEntry> logEntries, LogEntrySync logEntrySync) {
        logEntryRepository.updateAll(logEntries);
        logEntrySyncRepository.update(logEntrySync);
    }

    Optional<de.fhg.ivi.ids.logginghouse.persistence.LogEntry> map(Message message, LogEntry entry) {

        MessageType type = getMessageType(message);

        if (type == null) {
            log.trace("Unsupported message type. Log entry {} payload of for PID {} to IDS Message. Message:\n{}",
                    entry.getId(), entry.getPid(), entry);
            return Optional.empty();
        }

        var correlationMessage = Optional.ofNullable(message.getCorrelationMessage())
                .map(URI::toString).orElse(null);

        var issuerConnector = entry.getIssuerConnector()
                .map(Part::getContent).orElse(null);

        var log = new de.fhg.ivi.ids.logginghouse.persistence.LogEntry()
                .setId(entry.getId())
                .setPid(entry.getPid())
                .setIssuerConnectorId(message.getIssuerConnector().toString())
                .setRecipientConnectorId(message.getRecipientConnector().get(0).toString())
                .setCorrelationMessageId(correlationMessage)
                .setMessageId(message.getId().toString())
                .setTimestamp(instantMapper.map(message.getIssued()))
                .setMessageType(type)
                .setLogConnectorId(issuerConnector);

        return Optional.of(log);
    }

    private MessageType getMessageType(Message message) {
        if (message instanceof RequestMessage) {
            return MessageType.REQUEST;
        } else if (message instanceof ResponseMessage) {
            return MessageType.RESPONSE;
        } else {
            return null;
        }
    }

    private Optional<Message> parseMessage(String message) {
        try {
            return Optional.of(serializer.deserialize(message, Message.class));
        } catch (IOException e) {
            log.trace("Could not deserialize log message: {}", message);
            return Optional.empty();
        }
    }

    private Optional<String> getPidFromAgreementId(URI id) {
        var segments = id.getPath().split("/");
        if (segments.length == 0) {
            return Optional.empty();
        }
        return Optional.of(segments[segments.length - 1]);
    }

    private long getLastSyncedPage(String id) {
        return logEntrySyncRepository.findById(id)
                .map(LogEntrySync::getPage)
                .orElse(1L);
    }
}