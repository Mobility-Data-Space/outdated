package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.persistence.Contract;
import lombok.Data;

@Data
public class LogStatistic {

    Contract contract;

    long requestsSent;

    long requestsReceived;

    long responsesSent;

    long responsesReceived;

}
