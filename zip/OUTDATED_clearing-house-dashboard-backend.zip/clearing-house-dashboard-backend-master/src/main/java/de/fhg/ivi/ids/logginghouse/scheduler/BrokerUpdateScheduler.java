package de.fhg.ivi.ids.logginghouse.scheduler;

import de.fhg.ivi.ids.logginghouse.BrokerUpdateService;
import io.micronaut.context.annotation.Requires;
import io.micronaut.scheduling.annotation.Scheduled;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Requires(property = "logginghouse.brokersync.enabled", value = "true", defaultValue = "false")
public class BrokerUpdateScheduler {

    @Inject
    BrokerUpdateService brokerUpdateService;

    @Scheduled(fixedDelay = "${logginghouse.brokersync.fixeddelay}", initialDelay = "${logginghouse.brokersync.initialdelay}")
    void schedule() {
        brokerUpdateService.update();
    }

}
