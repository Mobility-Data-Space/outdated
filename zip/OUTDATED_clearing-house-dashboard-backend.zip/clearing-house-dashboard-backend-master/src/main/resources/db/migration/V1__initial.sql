create table connector (
    id varchar(255) not null,
    access_url varchar(255),
    description text,
    owned boolean not null,
    title varchar(255),
    curator_id varchar(255),
    maintainer_id varchar(255),
    primary key (id)
);

create table connector_consumed_resources (
    connector_id varchar(255) not null,
    resource_id varchar(255) not null,
    primary key (connector_id, resource_id)
);

create table connector_resources (
    connector_id varchar(255) not null,
    resource_id varchar(255) not null,
    primary key (connector_id, resource_id)
);

create table data_category (
    id varchar(255) not null,
    logo varchar(255),
    name varchar(255),
    primary key (id)
);

create table participant (
    id varchar(255) not null,
    name varchar(255),
    primary key (id)
);

create table resource (
    id varchar(255) not null,
    created timestamp,
    description text,
    license varchar(255),
    modified timestamp,
    publisher varchar(255),
    title varchar(255),
    version varchar(255),
    primary key (id)
);

create table resource_datacategories (
    resource_id varchar(255) not null,
    datacategory_id varchar(255) not null,
    primary key (resource_id, datacategory_id)
);

create table contract (
    id bytea not null,
    contract_start timestamp,
    contract_end timestamp,
    contract_date timestamp,
    provider_id varchar(255) not null,
    consumer_id varchar(255) not null,
    primary key (id)
);

create table artifact (
    id varchar(255) not null,
    resource_id varchar(255),
    primary key (id)
);

create table contract_artifacts (
    contract_id bytea not null,
    artifact_id varchar(255) not null,
    primary key (contract_id, artifact_id)
);

create table log_entry (
    id varchar(255) not null,
    log_connector_id varchar(255) not null,
    recipient_connector_id varchar(255) not null,
    issuer_connector_id varchar(255) not null,
    pid varchar(255) not null,
    message_type smallint not null,
    message_id varchar(255) not null,
    correlation_message_id varchar(255),
    timestamp timestamp not null,
    primary key (id)
);

create table log_entry_sync (
    id varchar(255) not null,
    page BIGINT not null,
    primary key (id)
);

alter table if exists connector_resources add constraint connector_resource_unique_resource_id unique (resource_id);
alter table if exists connector add constraint connector_fk_curator_id foreign key (curator_id) references participant;
alter table if exists connector add constraint connector_fk_maintainer_id foreign key (maintainer_id) references participant;
alter table if exists connector_consumed_resources add constraint connector_consumed_resources_fk_resource_id foreign key (resource_id) references resource;
alter table if exists connector_consumed_resources add constraint connector_consumed_resources_fk_connector_id foreign key (connector_id) references connector;
alter table if exists connector_resources add constraint connector_resources_fk_resource_id foreign key (resource_id) references resource;
alter table if exists connector_resources add constraint connector_resources_fk_connector_id foreign key (connector_id) references connector;
alter table if exists resource_datacategories add constraint resource_datacategories_fk_datacategory_id foreign key (datacategory_id) references data_category;
alter table if exists resource_datacategories add constraint resource_datacategories_fk_resource_id foreign key (resource_id) references resource;
alter table if exists contract add constraint contract_fk_provider_id foreign key (provider_id) references connector;
alter table if exists contract add constraint contract_fk_consumer_id foreign key (consumer_id) references connector;
alter table if exists contract_artifacts add constraint contract_artifacts_fk_contract_id foreign key (contract_id) references contract;
alter table if exists contract_artifacts add constraint contract_artifacts_fk_artifact_id foreign key (artifact_id) references artifact;
alter table if exists artifact add constraint artifact_fk_resource_id foreign key (resource_id) references resource;