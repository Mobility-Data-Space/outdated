package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.ch.model.LogEntry;
import de.fhg.ivi.ids.logginghouse.ch.model.Part;
import de.fhg.ivi.ids.logginghouse.infomodel.TestContractAgreement;
import de.fhg.ivi.ids.logginghouse.infomodel.TestPermission;
import de.fhg.ivi.ids.logginghouse.persistence.ContractRepository;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;

import javax.inject.Inject;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.net.URI;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

@MicronautTest(environments = "postgres")
public class ClearingHouseUpdateServiceTest {

    @Inject
    ClearingHouseUpdateService clearingHouseUpdateService;

    @Inject
    ContractRepository contractRepository;

    @Test
    public void save() {
        var contractId = URI.create("http://contract");
        var consumer = URI.create("http://consumer");
        var provider = URI.create("http://provider");
        var to = Instant.now();
        var from = to.minus(10, ChronoUnit.DAYS);
        var contractAgreement = new TestContractAgreement()
                .setId(contractId)
                .setContractStart(toCalendar(from))
                .setContractEnd(toCalendar(to))
                .setConsumer(consumer)
                .setProvider(provider)
                .setPermission(new ArrayList(List.of(new TestPermission().setTarget(URI.create("http://artifact")))));

        clearingHouseUpdateService.save(contractAgreement);

        var contract = contractRepository.findById(contractId).orElseThrow();
        assertEquals(1, contract.getArtifacts().size());
        assertEquals(consumer.toString(), contract.getConsumer().getId());
        assertEquals(provider.toString(), contract.getProvider().getId());
    }

    @Test
    void parseContract_BrokenContract() {
        var logEntry = new LogEntry().setParts(List.of(new Part().setName("payload").setContent("falsch")));
        var result = clearingHouseUpdateService.parseContract(logEntry);

        //noinspection OptionalAssignedToNull
        if (result == null || result.isPresent()) {
            fail("Result of parseContract should be emtpy.");
        }
    }

    XMLGregorianCalendar toCalendar(Instant instant) {
        GregorianCalendar cal1 = new GregorianCalendar();
        cal1.setTimeInMillis(instant.toEpochMilli());
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal1);
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
            return null;
        }
    }
}
