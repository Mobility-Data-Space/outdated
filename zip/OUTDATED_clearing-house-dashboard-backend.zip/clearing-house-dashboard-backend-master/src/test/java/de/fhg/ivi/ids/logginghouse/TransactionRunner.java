package de.fhg.ivi.ids.logginghouse;

import javax.inject.Singleton;
import javax.transaction.Transactional;
import java.util.function.Supplier;

@Singleton
public class TransactionRunner {

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    public <R> R doInTransaction(Supplier<R> s) {
        return s.get();
    }
}
