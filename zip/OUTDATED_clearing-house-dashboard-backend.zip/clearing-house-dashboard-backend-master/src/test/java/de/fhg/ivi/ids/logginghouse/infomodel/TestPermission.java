package de.fhg.ivi.ids.logginghouse.infomodel;

import de.fraunhofer.iais.eis.Action;
import de.fraunhofer.iais.eis.Constraint;
import de.fraunhofer.iais.eis.Duty;
import de.fraunhofer.iais.eis.util.TypedLiteral;
import lombok.Data;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
public class TestPermission implements de.fraunhofer.iais.eis.Permission {
    URI id;
    List<TypedLiteral> label;
    List<TypedLiteral> comment;
    Map<String, Object> properties;
    URI target;
    ArrayList<? extends URI> assigner;
    ArrayList<? extends URI> assignee;
    ArrayList<? extends Constraint> constraint;
    ArrayList<? extends Action> action;
    ArrayList<? extends TypedLiteral> title;
    ArrayList<? extends TypedLiteral> description;

    @Override
    public String toRdf() {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

    @Override
    public void setProperty(String s, Object o) {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

    @Override
    public ArrayList<? extends Duty> getPreDuty() {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

    @Override
    public ArrayList<? extends Duty> getPostDuty() {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }


}