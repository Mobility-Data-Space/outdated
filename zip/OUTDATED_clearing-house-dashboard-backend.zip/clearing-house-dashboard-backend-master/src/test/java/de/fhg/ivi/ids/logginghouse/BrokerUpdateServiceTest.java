package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.broker.BrokerClient;
import de.fhg.ivi.ids.logginghouse.broker.model.BrokerConnector;
import de.fhg.ivi.ids.logginghouse.broker.model.BrokerResource;
import de.fhg.ivi.ids.logginghouse.persistence.ConnectorRepository;
import de.fhg.ivi.ids.logginghouse.persistence.ResourceRepository;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;

import javax.inject.Inject;
import javax.transaction.Transactional;

import java.net.URI;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

import static javax.transaction.Transactional.TxType.REQUIRES_NEW;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest(environments = "postgres")
public class BrokerUpdateServiceTest {

    @Inject
    BrokerClient mockedBrokerClientMock;

    @Inject
    BrokerUpdateService brokerUpdateService;

    @Inject
    ConnectorRepository connectorRepository;

    @Inject
    ResourceRepository resourceRepository;

    @Test
    void update() {
        when(mockedBrokerClientMock.getConnectors()).thenReturn(List.of(getBrokerConnector()));
        when(mockedBrokerClientMock.getResources()).thenReturn(List.of(getBrokerResource()));

        // when
        brokerUpdateService.update();

        // then
        var connectors = connectorRepository.findAll();

        assertEquals(1, connectors.size());
        assertEquals(1, connectors.get(0).getResources().size());
        assertEquals(1, connectors.get(0).getResources().iterator().next().getArtifacts().size());
    }

    @Test
    void updateResourceWithoutConnectorId() {
        var r = getBrokerResource().setConnectorId(null);
        when(mockedBrokerClientMock.getResources()).thenReturn(List.of(r));
        when(mockedBrokerClientMock.getConnectors()).thenReturn(List.of());

        // when
        brokerUpdateService.update();

        var connectors = connectorRepository.findAll();
        assertEquals(0, connectors.size());

        var resources = resourceRepository.findAll();
        assertEquals(0, resources.size());
    }

    @Test
    void updateResourceWithEmptyStringDate() {
        var r = getBrokerResource().setCreated("");
        when(mockedBrokerClientMock.getResources()).thenReturn(List.of(r));
        when(mockedBrokerClientMock.getConnectors()).thenReturn(List.of(getBrokerConnector()));

        // when
        brokerUpdateService.update();

        var connectors = connectorRepository.findAll();
        assertEquals(1, connectors.size());
        assertEquals(1, connectors.get(0).getResources().size());
    }

    BrokerConnector getBrokerConnector() {
        return new BrokerConnector()
                        .setId("http://test")
                        .setTitle("test")
                        .setCurator(URI.create("http://ivi"))
                        .setUrl("http://test/api");
    }

    BrokerResource getBrokerResource() {
        return new BrokerResource()
                        .setId("http://test//offer/1")
                        .setConnectorId("http://test")
                        .setTitle("test")
                        .setPublisher("http://ivi")
                        .setArtifactIds(Set.of("http://test/api"));
    }

    @MockBean(BrokerClient.class)
    BrokerClient getMessagesApiClient() {
        return mock(BrokerClient.class);
    }

}
