package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.persistence.Connector;
import de.fhg.ivi.ids.logginghouse.persistence.ConnectorRepository;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest(environments = "postgres")
public class ConnectorUpdateServiceTest extends LoggingHouseTestSetup {

    @Inject
    ConnectorUpdateService connectorUpdateService;

    @Inject
    ConnectorRepository connectorRepository;

    @Inject
    ConnectorClient connectorClient;

    @Inject
    TransactionRunner transactionRunner;

    @Test
    public void update() {
        // given
        transactionRunner.doInTransaction(
                () -> connectorRepository.save(new Connector().setId(dbConnectorId))
        );
        when(connectorClient.getSelfDescription(any())).thenReturn(Optional.of(connectorDB));
        when(connectorClient.getResourceCatalogs(any(), any())).thenReturn(List.of(connectorDBResourceCatalog));

        // when
        connectorUpdateService.updateConnector(dbConnectorId);

        // then
        var connector = connectorRepository.findById(dbConnectorId).orElseThrow();
        assertEquals("https://www.ivi.fraunhofer.de/", connector.getCurator().getId());
        assertEquals("https://www.isst.fraunhofer.de/", connector.getMaintainer().getId());
        assertEquals(1, connector.getResources().size());
        assertEquals(0, connector.getConsumedResources().size());
        var resource = connector.getResources().iterator().next();
        assertEquals(1, resource.getArtifacts().size());
        var artifact = resource.getArtifacts().iterator().next();
        assertEquals("7fc2cb2f-285f-4950-86fc-0971c8f196b3", artifact.getId());
    }

    @MockBean(ConnectorClient.class)
    ConnectorClient getConnectorClient() {
        return mock(ConnectorClient.class);
    }
}
