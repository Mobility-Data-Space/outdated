package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.dsc.api.MessagesApiClient;
import io.micronaut.http.client.exceptions.HttpClientException;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;

import javax.inject.Inject;
import java.net.URI;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest(environments = "h2")
public class ConnectorClientTest {

    @Inject
    ConnectorClient connectorClient;

    @Inject
    MessagesApiClient messagesApiClient;

    @Test
    void sendRequest_Fail() {
        when(messagesApiClient.sendMessage3(any(), any(), any())).thenThrow(new HttpClientException("timeout"));

        var result = connectorClient.sendRequest(URI.create("http://test"), "", Optional.empty());

        assertTrue(result.isEmpty());
    }

    @MockBean(MessagesApiClient.class)
    MessagesApiClient mockMessagesApiClient() {
        return mock(MessagesApiClient.class);
    }
}
