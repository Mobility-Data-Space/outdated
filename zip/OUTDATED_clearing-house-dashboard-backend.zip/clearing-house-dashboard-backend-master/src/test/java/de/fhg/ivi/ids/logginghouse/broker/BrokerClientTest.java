package de.fhg.ivi.ids.logginghouse.broker;

import de.fhg.ivi.ids.logginghouse.dsc.api.MessagesApiClient;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javax.inject.Inject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest(environments = {"h2", "test"})
public class BrokerClientTest {

    static String connectorQueryResultMessage;

    static String resourceQueryResultMessage;

    @Inject
    MessagesApiClient messagesApiClientMock;

    @Inject
    BrokerClient brokerClient;

    @BeforeAll
    static void before() throws IOException {
        connectorQueryResultMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/FullConnectorQuery_ResultMessage.txt"));

        resourceQueryResultMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/ResourceQuery_ResultMessage.txt"));
    }

    @Test
    void getConnectors() {
        when(messagesApiClientMock.sendQueryMessage(any(), any(), any())).thenReturn(connectorQueryResultMessage);

        var result = brokerClient.getConnectors();

        assertEquals(20, result.size());
    }

    @Test
    void getResources() {
        when(messagesApiClientMock.sendQueryMessage(any(), any(), any())).thenReturn(resourceQueryResultMessage);

        var result = brokerClient.getResources();

        assertEquals(20, result.size());

        String id = "https://ids2.highq-projekte.de/api/offers/0bb5029e-0e9d-47ab-894e-793d0eb16daf";
        var resource = result.stream()
                .filter(brokerResource -> id.equals(brokerResource.getId()))
                .findAny()
                .orElseThrow();
        assertEquals(2, resource.getArtifactIds().size());
        assertEquals("test description", resource.getDescription());
    }

    @MockBean(MessagesApiClient.class)
    MessagesApiClient getMessagesApiClient() {
        return mock(MessagesApiClient.class);
    }
}
