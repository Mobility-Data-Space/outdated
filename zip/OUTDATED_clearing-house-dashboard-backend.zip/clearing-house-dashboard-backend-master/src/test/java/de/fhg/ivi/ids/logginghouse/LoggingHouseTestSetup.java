package de.fhg.ivi.ids.logginghouse;

import de.fraunhofer.iais.eis.BaseConnector;
import de.fraunhofer.iais.eis.Connector;
import de.fraunhofer.iais.eis.ResourceCatalog;
import de.fraunhofer.iais.eis.ids.jsonld.Serializer;
import org.junit.jupiter.api.BeforeAll;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Set;

public abstract class LoggingHouseTestSetup {
    static Serializer serializer = new Serializer();

    static String connectorQueryResultMessage;

    static String dbConnectorId = "https://ids.db-connector.test.mobilitydataspace.io";
    static String connectorDBSelfDescriptionMessage;
    static Connector connectorDB;
    static String connectorDBResourceDescriptionMessage;
    static ResourceCatalog connectorDBResourceCatalog;

    static String connectorIVISelfDescriptionMessage;
    static Connector connectorIVI;
    static ResourceCatalog connectorIVIResourceCatalog;
    static Set<URI> iVIRequestedDBResource;
    static Set<URI> iVIRequestedIVIResource;

    static String connectorIVIResourceDescriptionMessage;
    static String emptyConnectorSelfDescriptionMessage;
    static Connector emptyConnector;

    static String connectorDWDResourceDescriptionMessage;
    static ResourceCatalog connectorDWDResourceCatalog;

    @BeforeAll
    static void before() throws IOException {
        connectorQueryResultMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/ConnectorQuery_ResultMessage.txt"));

        connectorDBSelfDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/DBConnector_SelfDescription.txt"));

        emptyConnectorSelfDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/EmptyConnector_SelfDescription.txt"));

        connectorIVISelfDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/IVIConnector_SelfDescription.txt"));

        connectorDBResourceDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/DBResource_Catalog.json"));

        connectorIVIResourceDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/IVIResource_Catalog.json"));

        iVIRequestedDBResource =
                Set.of(URI.create("https://ids.db-connector.test.mobilitydataspace.io/api/offers/4d8e7a38-b05f-4ad4-a649-faf29fa703c8"));
        iVIRequestedIVIResource =
                Set.of(URI.create("https://ids.ivi-connector.test.mobilitydataspace.io/api/offers/f492d35c-de8f-4660-ab04-14a563d400d2"));

        connectorDWDResourceDescriptionMessage =
                Files.readString(Paths.get("src/test/resources/ids_responses/DWDResource_Catalog.json"));

        connectorDB = createConnector(connectorDBSelfDescriptionMessage);
        emptyConnector = createConnector(emptyConnectorSelfDescriptionMessage);
        connectorIVI = createConnector(connectorIVISelfDescriptionMessage);
        connectorDBResourceCatalog = createResourceCatalog(connectorDBResourceDescriptionMessage);
        connectorIVIResourceCatalog = createResourceCatalog(connectorIVIResourceDescriptionMessage);
        connectorDWDResourceCatalog = createResourceCatalog(connectorDWDResourceDescriptionMessage);
    }

    static BaseConnector createConnector(String connector1SelfDescriptionMessage) throws IOException {
        return serializer.deserialize(connector1SelfDescriptionMessage, BaseConnector.class);
    }

    static ResourceCatalog createResourceCatalog(String resourceCatalog) throws IOException {
        return serializer.deserialize(resourceCatalog, ResourceCatalog.class);
    }

}
