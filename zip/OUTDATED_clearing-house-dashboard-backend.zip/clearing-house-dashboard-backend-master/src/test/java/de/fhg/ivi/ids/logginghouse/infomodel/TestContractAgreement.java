package de.fhg.ivi.ids.logginghouse.infomodel;

import de.fraunhofer.iais.eis.*;
import de.fraunhofer.iais.eis.util.TypedLiteral;
import lombok.Data;

import javax.xml.datatype.XMLGregorianCalendar;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
public class TestContractAgreement implements de.fraunhofer.iais.eis.ContractAgreement {
    URI id;
    List<TypedLiteral> label;
    List<TypedLiteral> comment;
    Map<String, Object> properties;
    ArrayList<? extends Permission> permission;
    ArrayList<? extends Prohibition> prohibition;
    ArrayList<? extends Duty> obligation;
    XMLGregorianCalendar contractStart;
    XMLGregorianCalendar contractEnd;
    XMLGregorianCalendar contractDate;
    URI provider;
    URI consumer;
    TextResource contractDocument;
    Resource contractAnnex;

    @Override
    public String toRdf() {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

    @Override
    public void setProperty(String s, Object o) {
        throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }

}
