package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.api.DataspaceViewApiTestClient;
import de.fhg.ivi.ids.logginghouse.api.DataspaceViewApiTestSpec;
import de.fhg.ivi.ids.logginghouse.model.LinkValue;
import de.fhg.ivi.ids.logginghouse.model.NodeValue;
import io.micronaut.http.HttpStatus;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import javax.inject.Inject;
import java.io.IOException;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;

@MicronautTest(environments = "postgres")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class LoggingHouseControllerTest extends ControllerTestSetup implements DataspaceViewApiTestSpec {

    @Inject
    DataspaceViewApiTestClient client;

    @Inject
    LoggingHouseController loggingHouseController;

    @Override
    @Disabled
    public void getConfig200() {

    }

    @Test
    @Override
    public void getConnectorData200() {

        var response = client.getConnectorData(CONNECTOR_1_ID, null, null);

        var connectorValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(1, connectorValue.getDataCategories().size());
        assertEquals(CATEGORY_ID, connectorValue.getDataCategories().get(0).getName());

    }

    @Override
    public void getConnectorData400() {

    }

    @Test
    @Override
    public void getConnectorData404() {
        var response = client.getConnectorData("does not exist", null, null);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatus());
    }

    @Override
    @Test
    public void getDataspaceLayout200() {
        var response = client.getDataspaceLayout(null, null);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(3, dataspaceLayoutValue.getNodes().size());

        // connector assertions
        var connectorNodeValue = dataspaceLayoutValue.getNodes().stream()
                .filter(node -> node.getId().equals(CONNECTOR_1_ID))
                .findAny()
                .orElseThrow();
        assertEquals(CURATOR_ID, connectorNodeValue.group());
        assertEquals(NodeValue.Type.CONNECTOR, connectorNodeValue.getType());
        assertEquals(CONNECTOR_1_TITLE, connectorNodeValue.getName());

        // participant assertions
        var participantNodeValue = dataspaceLayoutValue.getNodes().stream()
                .filter(node -> node.getId().equals(CURATOR_ID))
                .findAny()
                .orElseThrow();
        assertEquals(CURATOR_ID, participantNodeValue.group());
        assertEquals(NodeValue.Type.CURATOR, participantNodeValue.getType());
        assertEquals(CURATOR_TITLE, participantNodeValue.getName());

        // link assertions
        assertEquals(3, dataspaceLayoutValue.getLinks().size());
        LinkValue linkValue = dataspaceLayoutValue.getLinks().get(0);

        assertTrue(linkValue.getSource().equals(CONNECTOR_1_ID) && linkValue.getTarget().equals(CURATOR_ID) ||
                linkValue.getSource().equals(CURATOR_ID) && linkValue.getTarget().equals(CONNECTOR_1_ID));

        linkValue = dataspaceLayoutValue.getLinks().get(1);
        assertTrue(linkValue.getSource().equals(CONNECTOR_2_ID) && linkValue.getTarget().equals(CURATOR_ID) ||
                linkValue.getSource().equals(CURATOR_ID) && linkValue.getTarget().equals(CONNECTOR_2_ID));
    }

    @Test
    public void getDataspaceLayout200_BeforeContract() {
        var from = contractStart.minus(2, ChronoUnit.DAYS);
        var to = contractStart.minus(1, ChronoUnit.DAYS);

        var response = client.getDataspaceLayout(from, to);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(0, dataspaceLayoutValue.getNodes().size());
    }

    @Test
    public void getDataspaceLayout200_AtContract() {
        var response = client.getDataspaceLayout(contractStart, contractEnd);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(3, dataspaceLayoutValue.getNodes().size());
    }

    @Test
    public void getDataspaceLayout200_InContract() {
        var from = contractStart.plus(1, ChronoUnit.HOURS);
        var to = contractEnd.minus(1, ChronoUnit.HOURS);

        var response = client.getDataspaceLayout(from, to);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(3, dataspaceLayoutValue.getNodes().size());
    }

    @Test
    public void getDataspaceLayout200_AfterContract() {
        var to = contractEnd.plus(2, ChronoUnit.DAYS);

        var response = client.getDataspaceLayout(contractEnd, to);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(0, dataspaceLayoutValue.getNodes().size());
    }

    @Test
    public void getDataspaceLayout200_OverlappingEndContract() {
        var from = contractEnd.minus(1, ChronoUnit.HOURS);
        var to = contractEnd.plus(1, ChronoUnit.DAYS);

        var response = client.getDataspaceLayout(from, to);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(3, dataspaceLayoutValue.getNodes().size());
    }

    @Test
    public void getDataspaceLayout200_OverlappingStartContract() {
        var from = contractStart.minus(1, ChronoUnit.HOURS);
        var to = contractStart.plus(1, ChronoUnit.DAYS);

        var response = client.getDataspaceLayout(from, to);

        var dataspaceLayoutValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(3, dataspaceLayoutValue.getNodes().size());
    }

    @Override
    public void getDataspaceLayout400() {

    }

    @Test
    @Override
    public void getLinkData200() {
        var response = client.getLinkData(CONNECTOR_1_ID, CONNECTOR_2_ID, null, null);

        var resourceLinkValue = assertDoesNotThrow(() -> response.getBody().orElseThrow());
        assertEquals(0, resourceLinkValue.getIncoming().size());
        assertEquals(1, resourceLinkValue.getOutgoing().size());
        var resource = resourceLinkValue.getOutgoing().get(0);
        assertEquals("resource title", resource.getName());
        assertEquals(CATEGORY_ID, resource.getDataCategories().get(0));
        assertEquals("1", resource.getContractId());
    }

    @Test
    @Override
    public void getLinkData404() {
        var response =
                client.getLinkData(CONNECTOR_1_ID, "gibts doch gar nicht", null, null);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatus());
    }

    @Test
    void getDownloadFileName() {
        var result = LoggingHouseController.getDownloadFileName(contractStart, contractEnd);
        assertEquals("logs_2022-03-23_2022-03-24.csv", result);
    }

    @Test
    void downloadFile() throws IOException {
        var csv = loggingHouseController.download(contractStart, contractEnd);

        var result = new String(csv.getInputStream().readAllBytes());

        var expectedResult =
                "Provider_id,Consumer_id,Contract_id,Resource_Title,Requests_Sent,Requests_Received,Responses_Sent,Responses_Received\n" +
                "1,2,http://contract/1,resource title,0,0,0,0";

        assertEquals(expectedResult, result);
    }

}
