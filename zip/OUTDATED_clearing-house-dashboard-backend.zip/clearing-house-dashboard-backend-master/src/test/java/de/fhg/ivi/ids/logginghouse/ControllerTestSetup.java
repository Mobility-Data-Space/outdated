package de.fhg.ivi.ids.logginghouse;

import de.fhg.ivi.ids.logginghouse.persistence.*;
import org.junit.jupiter.api.BeforeAll;

import javax.inject.Inject;
import javax.transaction.Transactional;
import java.net.URI;
import java.time.Instant;
import java.util.Set;

public abstract class ControllerTestSetup {

    public static final String CONNECTOR_1_ID = "1";
    public static final String CONNECTOR_1_TITLE = "connector title";

    public static final String CONNECTOR_2_ID = "2";
    public static final String CONNECTOR_2_TITLE = "connector title";

    public static final String CURATOR_ID = "curator";
    public static final String CURATOR_TITLE = "curator title";

    public static final String RESOURCE_ID = "resource";
    public static final String RESOURCE_TITLE = "resource title";
    public static final String RESOURCE_DESCRIPTION = "resource description";

    public static final String CATEGORY_ID = "cat:Klima_und_Wetter";

    public static final String CONTRACT_ID = "http://contract/1";

    public static final Instant contractStart = Instant.ofEpochSecond(1648040899); // Wednesday, 23. March 2022 13:08:19
    public static final Instant contractEnd = Instant.ofEpochSecond(1648127299); // Thursday, 24. March 2022 13:08:19

    @Inject
    ConnectorRepository connectorRepository;

    @Inject
    ParticipantRepository participantRepository;

    @Inject
    DataCategoryRepository dataCategoryRepository;

    @Inject
    ContractRepository contractRepository;

    @Inject
    ArtifactRepository artifactRepository;

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    @BeforeAll
    void init() {
        DataCategory dataCategory = new DataCategory()
                .setId(CATEGORY_ID)
                .setName(CATEGORY_ID);
        dataCategory = dataCategoryRepository.save(dataCategory);

        Resource resource = new Resource()
                .setId(RESOURCE_ID)
                .setTitle(RESOURCE_TITLE)
                .setCreated(Instant.ofEpochMilli(1626825600)) // 21. July 2021 00:00:00
                .setModified(Instant.ofEpochMilli(1626825600))
                .setDescription(RESOURCE_DESCRIPTION)
                .setDataCategories(Set.of(dataCategory));

        Participant curator = new Participant()
                .setId(CURATOR_ID)
                .setName(CURATOR_TITLE);
        var curatorEntity = participantRepository.save(curator);

        Connector connector1 = new Connector()
                .setId(CONNECTOR_1_ID)
                .setCurator(curatorEntity)
                .setTitle(CONNECTOR_1_TITLE)
                .setOwned(true)
                .setResources(Set.of(resource));

        Connector connector2 = new Connector()
                .setId(CONNECTOR_2_ID)
                .setCurator(curatorEntity)
                .setTitle(CONNECTOR_2_TITLE)
                .setConsumedResources(Set.of(resource));

        var c1 = connectorRepository.save(connector1);
        var c2 = connectorRepository.save(connector2);
        var artifact = new Artifact()
                .setId("http://artifact/1")
                .setResource(resource);
        var a1 = artifactRepository.save(artifact);

        Contract contract = new Contract()
                .setId(URI.create(CONTRACT_ID))
                .setProvider(c1)
                .setConsumer(c2)
                .setContractStart(contractStart)
                .setContractEnd(contractEnd)
                .setArtifacts(Set.of(a1));
        contractRepository.save(contract);
    }
}
