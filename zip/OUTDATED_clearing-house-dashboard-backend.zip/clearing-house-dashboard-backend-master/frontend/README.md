# Dataspace Insights Frontend

This is a Javascript Application presenting a dataspace.
Used technologies:

- [D3.js](https://d3js.org/) for rendering
- [Apollo Client](https://www.apollographql.com/docs/react/) for state management
- [Snowpack](https://www.snowpack.dev/) as primary build/dev-tool
- [Node.js](https://nodejs.org/) as runtime

## Development

1. use node 16
2. run `npm ci` to install dependencies
3. have the backend available (localhost:4000) or adjust the backend-adress in `snowpack.config.mjs`
4. run `npm start` to start the development server
5. open the browser
6. edit files in the app folder and save, they get reloaded automatically


## Bundle Webapp

run `npm run build` to create the final webapp (static files).

## Docker usage

The bundled Webapp can be deployed with a docker container by using the included `Dockerfile`.
Note it will also include a redirect for /graphql to http://graphql:4000/ , which should be in the same docker network and be running the graphql endpoint.
Running both over the same nginx will prevent problems caused by origin-policies in the browser (and will save the preflight request required for that).