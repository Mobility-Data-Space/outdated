// Snowpack Configuration File
// See all supported options: https://www.snowpack.dev/reference/configuration
import proxy from 'http2-proxy'
const ApiBackend = {hostname: "drm-logging-t.ivi.fraunhofer.de", port: 8081}
// const ApiBackend = {hostname: "logging.test.mobilitydataspace.io", port: 443, protocol:"https"}
/** @type {import("snowpack").SnowpackUserConfig } */
export default {
  mount: {
    app: "/vis"
  },
  plugins: [
    /* ... */
  ],
  packageOptions: {
    /* ... */
  },
  devOptions: {
    openUrl: 'vis/index.html'
  },
  buildOptions: {
    out: '../target/build'
  },
  routes: [
    {
      src: '/config',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
    {
      src: '/dataspace-layout',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
    {
      src: '/connector-data/.*',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
    {
      src: '/resource-link*',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
    {
      src: '/own-connector',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
    {
      src: '/config',
      dest: (req, res) => {
        return proxy.web(req, res, ApiBackend);
      },
    },
  ]
};
