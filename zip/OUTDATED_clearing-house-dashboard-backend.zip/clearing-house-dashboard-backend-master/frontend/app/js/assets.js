/* eslint-disable no-unused-vars */
export { default as PLACEHOLDER_LOGO } from '../data/placeholder.png'
import cellulardata from '../data/img/categories/icon_service_cellulardata.png'
import cloud from '../data/img/categories/icon_service_cloud.png'
import embedded from '../data/img/categories/icon_service_embedded.png'
import gps from '../data/img/categories/icon_service_gps.png'
import railway from '../data/img/categories/icon_service_railway.png'
import trafficvolume from '../data/img/categories/icon_service_trafficvolume.png'
import dynamictraffic from '../data/img/categories/icon_service_dynamic_traffic_signs.png'
import trafficsigns from '../data/img/categories/icon_service_traffic_signs.png'
import ico_undefined from '../data/img/categories/icon_service_undefined.png'


// dokumentierte Kategorien Stand 06.10.2021 https://wissen.ivi.fraunhofer.de/display/OE221/Datenkategorien
// [
//     "Allgemeine Informationen zur Wegeplanung",
//     "Baustelleninformationen",
//     "Car und Bike Sharing",
//     "Dynamische Verkehrsschilder und Verkehrsregelungen",
//     "Echtzeit-Verkehrsdaten",
//     "Fracht und Logistik",
//     "Fußverkehrsnetze",
//     "Informationen über Parkplätze und Rastanlagen",
//     "Markttransparenzstelle für Kraftstoffe",
//     "Mautinformationen",
//     "Öffentlicher Verkehr: Betriebsinformationen",
//     "Öffentlicher Verkehr: Fahrpreis- und Vertriebsinformationen",
//     "Öffentlicher Verkehr: Ortsinformationen",
//     "Radverkehrsnetze",
//     "Sonstige",
//     "Statische Straßendaten",
//     "Statische Verkehrsschilder und Verkehrsregelungen",
//     "Straßenwetterinformationen",
//     "Tank- und Ladestationen",
//     "Unerwartete Ereignisse und Bedingungen",
//     "Strassen",
//     "Wasserstraßen und Gewässe",
//     "Klima und Wetter",
//     "Bahn",
//     "Infrastruktur",
//     "Luft- und Raumfahrt"
// ]


const categoryIcons = {
    "Allgemeine Informationen zur Wegeplanung": gps,
    "Dynamische Verkehrsschilder und Verkehrsregelungen": dynamictraffic,
    "Statische Verkehrsschilder und Verkehrsregelungen": trafficsigns,
    "trafficdata": trafficvolume,
    "Car und Bike Sharing": trafficvolume,
    "Mautinformationen": trafficvolume,
    "Bahn": railway,
    "Klima_und_Wetter": cloud,
    "undefined": ico_undefined
}
export function iconUriForDataCategory(category) {
    return categoryIcons[category?.name] || categoryIcons["undefined"]
}