import * as d3 from "d3"
import { iconUriForDataCategory } from "../../assets.js"
import { resourceLink } from "../backend.js"
import { makeGroupStructure, ownAssociatedGraph } from "../graph.js"
import { isParticipantView } from "../location-view-selector.js"
import { last } from "../utils.js"

export class ChordVisualisationRenderer {
    activeLink = undefined
    noTransmissionVisible = false
    constructor() {
    }

    generateSVG(data) {
        const container = d3.select(".groupContainerWrapper")
        container.selectAll("*:not(#overlay):not(#overlay *)").remove()

        const width = window.innerWidth;
        const height = window.innerHeight - document.querySelector("#overlay").clientHeight
        const minScreenDim = Math.min(width, height)
        const scaling = minScreenDim / 1000

        const radius = minScreenDim / 2;
        const anglePerItem = (Math.PI * 2) / data.totalCount

        const participantRadii = { outer: radius, inner: radius * .955 }
        const resourceRadii = { outer: radius * .95, inner: radius * .905 }
        const padAngle = 0.005
        const arcCornerRadius = 3 * scaling

        const textPadding = 6 * scaling

        const useHierarchicalEdgeBundling = true;

        container.style("height", height)
        container.style("width", width)


        const zoom = d3.zoom()
            .extent([[-width / 1000, -height / 1000], [width / 1000, height / 1000]])
            .scaleExtent([.8, 10])
            .on("start", () => {
                svg.style("transition", "none")
            })
            .on("end", () => {
                svg.style("transition", "all var(--animation-time)")
            })
            .on("zoom", (e) => {
                const transform = e.transform
                if (transform.k !== this.lastTransform?.k) {
                    svg.style("transition", "")
                } else {
                    svg.style("transition", "none")
                }
                svg.attr("transform", () => transform)
                this.lastTransform = transform
            })

        const svg = container.append("svg")
            .attr("overflow", "visible")
            .style("position", "absolute")
            .style("bottom", "0px")
            .style("left", "0px")
            .style("right", "0px")
            .style("transform-origin", "top left")
            .style("height", `${height}px`)
            .attr("viewBox", [-width / 2, -height / 2, width, height])

        container.call(zoom)



        const bgColors = [
            getComputedStyle(document.body).getPropertyValue("--color-bg"),
            getComputedStyle(document.body).getPropertyValue("--color-bg2")
        ]

        const mixBG = (t) => {
            return d3.interpolate(bgColors[0], bgColors[1])(Math.pow(t, 1))
        }
        const bgColorList = []

        for (let i = 0; i <= 1; i += 1 / 10) {
            bgColorList.push({
                offset: i,
                color: mixBG(i).toString()
            })
        }

        const linkBeta = .5
        const linkSubdivisions = 128
        const linkDebugView = false
        const linkOpacity = 1.
        const linkTintColor = "#fff"
        const linkTintIntensity = 0.2
        const linkLighten = 0.9
        const linkMidColorTint = "#fff"
        const linkMidColorIntensity = .5
        const linkWidth = 2 * scaling
        const linkHoverWidth = 5 * scaling
        const linkBackground = true
        const linkBackgroundWidth = 8 * scaling
        const linkBackgroundColor = "transparent"


        var defs = svg.append("defs");
        defs.append("radialGradient")
            .attr("id", "svgbg")
            .selectAll("stop")
            .data(bgColorList)
            .enter().append("stop")
            .attr("offset", function (d) { return d.offset; })
            .attr("stop-color", function (d) { return d.color; });

        svg.append("circle")
            .attr("cx", 0)
            .attr("cy", 0)
            .attr("r", radius * 2.0)
            .attr("fill", "url(#svgbg)")

        const links = svg.append("g")
            .classed("links", true)
            .style("filter", `drop-shadow(0px 0px ${scaling}px #000c) contrast(1.2)`)

        const participantRing = svg.append("g").classed("outer", true)
        const resourceRing = svg.append("g").classed("inner", true)

        const participantData = data.groups
        const resourceData = data.groups.flatMap(g => g.connectors.flatMap(connector => connector.resources.map((r, resourceIndex) => ({ ...r, connector, renderArc: resourceIndex === 0 }))))

        participantRing.selectAll(".participant").data(participantData)
            .join(
                enter => {

                    const innerRadius = participantRadii.inner
                    const logoSize = (radius - innerRadius) * .8

                    let maxTextWidthPerItem = 0
                    let availableWidthPerItem = innerRadius * Math.PI * 2 / data.totalCount - textPadding * 2


                    const participant = enter.append("g")
                        .classed("participant", true)
                        .attr("id", (d, i) => d.id + i)

                    const inputArc = participant.append("path")
                        .attr("id", d => "participant_arc_" + d.id)
                        .style("fill", d => d.color)
                        .attr("d", d => {
                            return d3.arc()
                                .cornerRadius(arcCornerRadius)
                                .outerRadius(participantRadii.outer)
                                .innerRadius(resourceRadii.inner)
                                .padAngle(padAngle)
                                .startAngle(anglePerItem * d.startsAt)
                                .endAngle(anglePerItem * (d.startsAt + 1))()
                        })

                    const mainArc = participant.append("path")
                        .attr("id", d => "participant_arc_" + d.id)
                        .style("fill", d => d.color)
                        .attr("d", d => {
                            return d3.arc()
                                .cornerRadius(arcCornerRadius)
                                .outerRadius(participantRadii.outer)
                                .innerRadius(participantRadii.inner)
                                .padAngle(padAngle)
                                .startAngle(anglePerItem * d.startsAt)
                                .endAngle(anglePerItem * (d.startsAt + d.size))()
                        })

                    function getLogoLocation(d) {
                        const r = (participantRadii.inner + resourceRadii.inner) / 2
                        return {
                            x: Math.sin((d.startsAt + .5) * anglePerItem) * r,
                            y: -Math.cos((d.startsAt + .5) * anglePerItem) * r,
                        }
                    }

                    const logos = participant
                        .append("image")
                        .attr("href", d => d.logo)
                        .attr("x", d => getLogoLocation(d).x - logoSize / 2)
                        .attr("y", d => getLogoLocation(d).y - logoSize / 2)
                        .attr("width", logoSize + "px")
                        .attr("height", logoSize + "px")
                        .style("z-index", 100000)
                        .attr("transform", d => `rotate(${(d.startsAt + .5) * anglePerItem / Math.PI * 180}, ${getLogoLocation(d).x},${getLogoLocation(d).y})`)


                    const textArc = participant.append("path")
                        .attr("id", d => "text_arc_" + d.id)
                        .attr("d", d => {
                            const angleFrom = anglePerItem * d.startsAt
                            const angleTo = anglePerItem * (d.startsAt + d.size)

                            let startAngle = angleFrom
                            let endAngle = angleTo
                            let radius = participantRadii.inner
                            const midAngle = (angleFrom + angleTo) / 2
                            const shouldFlip = midAngle > Math.PI / 2 && midAngle < Math.PI * 3 / 2
                            if (shouldFlip) {
                                startAngle = angleTo
                                endAngle = angleFrom
                                radius = participantRadii.outer
                            }

                            return d3.arc()
                                .outerRadius(radius)
                                .innerRadius(radius)
                                .padAngle(padAngle * 2)
                                .startAngle(startAngle)
                                .endAngle(endAngle)()
                        })

                    const texts = participant.append("text")
                        .attr("dy", (participantRadii.inner - participantRadii.outer) * .3)
                        .append("textPath")
                        .attr("href", d => "#text_arc_" + d.id)
                        .attr("font-size", 1)
                        .attr("data-size", d => d.size)
                        .style("fill", d => d3.lab(d.color).b > 50 ? "black" : "white")
                        .text(d => d.name)
                        .style("pointer-events", "none")

                    texts.nodes().forEach(element => {
                        const textLength = element.getComputedTextLength()

                        const widthPerItem = textLength / (element.dataset.size)
                        element.dataset.textLength = textLength
                        if (widthPerItem > maxTextWidthPerItem) maxTextWidthPerItem = widthPerItem
                    })
                    texts.attr("font-size", Math.min(availableWidthPerItem / maxTextWidthPerItem, 10 * scaling))
                    texts.nodes().forEach(element => {
                        const shiftAmount = textPadding//(availableSpace - textLength) / 2
                        element.setAttribute("startOffset", shiftAmount + "px")
                    })
                }
            )

        resourceRing.selectAll(".resource").data(resourceData)
            .join(
                enter => {
                    const outerRadius = resourceRadii.outer
                    const innerRadius = resourceRadii.inner
                    const resource = enter.append("g")
                        .classed("resource", true)
                        .attr("id", (d, i) => d.id + i)

                    const arcs = resource.append("path").filter(d => d.renderArc)
                        .attr("id", d => "resource_arc_" + d.id)
                        .style("fill", d3.interpolate(bgColorList[5].color, "#fff")(.4))
                        .attr("d", d => {
                            return d3.arc()
                                .cornerRadius(arcCornerRadius)
                                .outerRadius(outerRadius)
                                .innerRadius(innerRadius)
                                .padAngle(padAngle)
                                .startAngle(anglePerItem * d.startsAt)
                                .endAngle(anglePerItem * (d.startsAt + d.connector.size))()
                        })
                    const badgeSize = radius * .03
                    const images = resource.append("image")
                        .attr("x", d => {
                            const angle = anglePerItem * (d.startsAt + .5);
                            return -(badgeSize / 2) + Math.sin(angle) * (outerRadius + innerRadius) * .5
                        })
                        .attr("y", d => {
                            const angle = anglePerItem * (d.startsAt + .5);
                            return -(badgeSize / 2) - Math.cos(angle) * (outerRadius + innerRadius) * .5
                        })
                        .style("pointer-events", "none")
                        .style("filter", "invert(1)")
                        .style("opacity", ".7")
                        .attr("width", badgeSize + "px")
                        .attr("height", badgeSize + "px")
                        .attr("href", d => d.icon)
                }
            )




        links.selectAll(".linkbackground")
            .data(
                data.groups
                    .flatMap(g => g.connectors.flatMap(conn => conn.resources.flatMap(res => res.links)))
                    .reduce((prev, curr) => {
                        if (!prev.some(link => link.source.id === curr.source.id && link.target.id === curr.target.id))
                            prev.push(curr)
                        return prev
                    }, []))
            .join(
                enter => {
                    const group = enter.append("g")
                        .classed("linkbackground", true)
                        .on("mouseenter", (e) => {
                            ;[...document.querySelectorAll(".link")].filter(el => el.id === e.target.id).forEach(el => el.parentElement.append(el))
                            setTimeout(() => {
                                d3.selectAll(".link").filter(el => el.id === e.target.id).classed("hover", true)
                                    .style("filter", `drop - shadow(0px 0px ${3 * scaling}px #0001) contrast(2.5);`)
                                    .selectAll("path")
                                    .style("stroke-width", linkHoverWidth)
                            }, 30)
                        })
                        .on("mouseleave", (e) => {
                            d3.selectAll(".link").filter(el => el.id === e.target.id).classed("hover", false)
                                .selectAll("path")
                                .style("stroke-width", linkWidth)
                            setTimeout(() => {
                                d3.selectAll(".link").filter(el => el.id === e.target.id).classed("hover", false)
                                    .selectAll("path")
                                    .style("stroke-width", linkWidth)
                            }, 30)
                        })
                        .attr("id", d => `link_${d.source.id}__${d.target.id}`)

                    const link = group.append("path")
                        .attr("fill", "none")
                        .attr("stroke-width", linkBackgroundWidth)
                        .attr("stroke", linkBackgroundColor)
                        .attr("fromColor", d => d.source.color)
                        .attr("toColor", d => d.target.color)
                        .each(d => {
                            if (d.source.id === this.activeLink?.source.id && d.target.id === this.activeLink?.target.id) {
                                this.renderLinkDetails(d)
                            }
                        })
                        .on("click", async (_, d) => {
                            this.renderLinkDetails(d)
                        })
                        .attr("d", (d, i, k) => {
                            const rad = resourceRadii.inner
                            const participantHierarchyLevelRadius = rad * (1 - 1 / 2) // inner circle for hierarchy bundling
                            const connectorHierarchyLevelRadius = rad * (1 - 1 / 4) // outer circle for hierarchy bundling

                            const allConnectors = data.groups.flatMap(g => g.connectors)

                            const sourceConnector = allConnectors.find(conn => conn.id === d.source.id)
                            const targetConnector = allConnectors.find(conn => conn.id === d.target.id)

                            const sourceGroup = data.groups.find(g => g.connectors.includes(sourceConnector))
                            const targetGroup = data.groups.find(g => g.connectors.includes(targetConnector))

                            let ignoreGroupLevel = false
                            if (sourceGroup === targetGroup) ignoreGroupLevel = true

                            const sourceParticipantAngle = anglePerItem * (sourceGroup.startsAt + .5 * sourceGroup.size)
                            const targetParticipantAngle = anglePerItem * (targetGroup.startsAt + .5 * targetGroup.size)

                            // this "+1" is necessary to skip the incoming "pseudo-resource"
                            const sourceConnectorAngle = anglePerItem * (sourceConnector.startsAt + 1 + .5 * (sourceConnector.size))
                            const targetConnectorAngle = anglePerItem * (targetConnector.startsAt + 1 + .5 * (targetConnector.size))

                            const sourceResourceAngle = anglePerItem * (sourceConnector.startsAt + (d.source.resourceIndex ?? 0) + 1.5)
                            const targetResourceAngle = anglePerItem * (targetGroup.startsAt + .5)

                            const sourceHierarchyLocations = {
                                resource: {
                                    x: Math.sin(sourceResourceAngle) * rad,
                                    y: -Math.cos(sourceResourceAngle) * rad
                                },
                                connector: {
                                    x: Math.sin(sourceConnectorAngle) * connectorHierarchyLevelRadius,
                                    y: -Math.cos(sourceConnectorAngle) * connectorHierarchyLevelRadius
                                },
                                participant: {
                                    x: Math.sin(sourceParticipantAngle) * participantHierarchyLevelRadius,
                                    y: -Math.cos(sourceParticipantAngle) * participantHierarchyLevelRadius
                                }
                            }

                            const targetHierarchyLocations = {
                                resource: {
                                    x: Math.sin(targetResourceAngle) * rad,
                                    y: -Math.cos(targetResourceAngle) * rad
                                },
                                connector: {
                                    x: Math.sin(targetConnectorAngle) * connectorHierarchyLevelRadius,
                                    y: -Math.cos(targetConnectorAngle) * connectorHierarchyLevelRadius
                                },
                                participant: {
                                    x: Math.sin(targetParticipantAngle) * participantHierarchyLevelRadius,
                                    y: -Math.cos(targetParticipantAngle) * participantHierarchyLevelRadius
                                }
                            }

                            let path
                            if (!linkDebugView) {
                                path = d3.line().curve(d3.curveBundle.beta(
                                    window.beta ?? linkBeta
                                ))(
                                    useHierarchicalEdgeBundling ? (
                                        [
                                            [sourceHierarchyLocations.resource.x, sourceHierarchyLocations.resource.y],
                                            [sourceHierarchyLocations.connector.x, sourceHierarchyLocations.connector.y],
                                            ...(ignoreGroupLevel ? [] : [[sourceHierarchyLocations.participant.x, sourceHierarchyLocations.participant.y],
                                            [0, 0],
                                            [targetHierarchyLocations.participant.x, targetHierarchyLocations.participant.y]]),
                                            // [targetHierarchyLocations.connector.x, targetHierarchyLocations.connector.y],
                                            [targetHierarchyLocations.resource.x, targetHierarchyLocations.resource.y],
                                        ]
                                    ) :
                                        (
                                            [
                                                [sourceHierarchyLocations.resource.x, sourceHierarchyLocations.resource.y],
                                                [0, 0],
                                                [targetHierarchyLocations.resource.x, targetHierarchyLocations.resource.y],
                                            ]
                                        )
                                )

                            } else {
                                path = d3.path()
                                path.moveTo(sourceHierarchyLocations.resource.x, sourceHierarchyLocations.resource.y)
                                path.lineTo(sourceHierarchyLocations.connector.x, sourceHierarchyLocations.connector.y)
                                path.lineTo(sourceHierarchyLocations.participant.x, sourceHierarchyLocations.participant.y)
                                path.lineTo(0, 0)
                                path.lineTo(targetHierarchyLocations.participant.x, targetHierarchyLocations.participant.y)
                                // path.lineTo(targetHierarchyLocations.connector.x, targetHierarchyLocations.connector.y)
                                path.lineTo(targetHierarchyLocations.resource.x, targetHierarchyLocations.resource.y)
                            }
                            return path
                        })
                }
            )
        const linkPaths = links.selectAll(".linkbackground path").nodes()

        const getColor = (path, name) => {
            const attr = path.getAttribute(name)
            let result
            if (attr.includes("var(--")) {
                result = getComputedStyle(document.body).getPropertyValue(attr.replace("var(", "").replace(")", ""))
            } else {
                result = attr
            }
            result = d3.interpolate(result, linkTintColor)(linkTintIntensity)
            result = d3.interpolate("transparent", result)(1)
            const hsl = d3.hsl(result)
            const lighten = linkLighten
            return result
        }

        const newCoords = linkPaths.map(path => {
            const length = path.getTotalLength()
            const coords = { first: [], second: [] }
            const stepSize = 1 / linkSubdivisions

            const midColor = d3.interpolate(
                d3.interpolate(
                    getColor(path, "fromColor"),
                    getColor(path, "toColor")
                )(.3),
                linkMidColorTint
            )(linkMidColorIntensity)
            const tau = Math.PI * 2
            for (let t = 0; t <= 1; t += stepSize) {
                const equalness = .5
                const i = t * equalness + (1 - equalness) * (Math.sin(t * tau) + t * tau) / tau
                const p = path.getPointAtLength(length * i)
                coords[t < .5 ? "first" : "second"].push({
                    x: p.x,
                    y: p.y,
                    t: i,
                    color: i < .5 ?
                        d3.interpolate(
                            getColor(path, "fromColor"),
                            midColor
                        )(i * 2) :
                        d3.interpolate(
                            midColor,
                            d3.interpolate(
                                getColor(path, "toColor"),
                                getColor(path, "fromColor"),
                            )(0)
                        )((i - .5) * 2)

                })
            }
            coords.first.push(coords.second[0])
            return { coords, id: path.parentElement.id }
        })

        if (!linkBackground)
            links.selectAll(".linkbackground").remove()

        const gradFirst = defs.selectAll(".link_gradient_first").data(newCoords)
            .enter()
            .append("linearGradient")
            .classed("link_gradient", true)
            .attr("id", (_, i) => `link_gradient_first_${i}`)
            .attr("x1", d => (d.coords.first[0].x < last(d.coords.first).x) ? 0 : 1)
            .attr("y1", d => (d.coords.first[0].y < last(d.coords.first).y) ? 0 : 1)
            .attr("x2", d => (d.coords.first[0].x < last(d.coords.first).x) ? 1 : 0)
            .attr("y2", d => (d.coords.first[0].y < last(d.coords.first).y) ? 1 : 0)
        gradFirst.append("stop")
            .attr("offset", "0")
            .attr("stop-color", d => d.coords.first[0].color)
        gradFirst.append("stop")
            .attr("offset", "1")
            .attr("stop-color", d => last(d.coords.first).color)

        const gradSecond = defs.selectAll(".link_gradient_second").data(newCoords)
            .enter()
            .append("linearGradient")
            .classed("link_gradient", true)
            .attr("id", (_, i) => `link_gradient_second_${i}`)
            .attr("x1", d => d.coords.second[0].x < last(d.coords.second).x ? 0 : 1)
            .attr("y1", d => d.coords.second[0].y < last(d.coords.second).y ? 0 : 1)
            .attr("x2", d => d.coords.second[0].x < last(d.coords.second).x ? 1 : 0)
            .attr("y2", d => d.coords.second[0].y < last(d.coords.second).y ? 1 : 0)
        gradSecond.append("stop")
            .attr("offset", "0")
            .style("stop-color", d => d.coords.second[0].color)
            .style("color", d => d.coords.second[0].color)
        gradSecond.append("stop")
            .attr("offset", "1")
            .style("stop-color", d => last(d.coords.second).color)
            .style("color", d => last(d.coords.second).color)



        const link = links.selectAll(".link").data(newCoords)
            .enter()
            .append("g")
            .classed("link", true)
            .style("opacity", linkOpacity)
            .attr("id", d => d.id)

        link.append("path")
            .classed("gradientfirst", true)
            .style("fill", "transparent")
            .style("stroke-linecap", "round")
            .style("stroke-width", linkWidth)
            .attr("stroke", (d, i) => `url(#link_gradient_first_${i})`)
            .attr("d", d => {
                const path = d3.path()
                path.moveTo(d.coords.first[0].x, d.coords.first[0].y)
                for (let i = 0; i < d.coords.first.length; i++)
                    path.lineTo(d.coords.first[i].x, d.coords.first[i].y)
                return path
            })

        link.append("path")
            .classed("gradientsecond", true)
            .style("fill", "transparent")
            .style("stroke-linecap", "round")
            .style("stroke-width", linkWidth)
            .attr("stroke", (d, i) => `url(#link_gradient_second_${i})`)
            .attr("d", d => {
                const path = d3.path()
                path.moveTo(d.coords.second[0].x, d.coords.second[0].y)
                for (let i = 0; i < d.coords.second.length; i++)
                    path.lineTo(d.coords.second[i].x, d.coords.second[i].y)
                return path
            })

    }

    async renderLinkDetails(link) {
        this.activeLink = link
        const sourceId = link.source.id, targetId = link.target.id
        try {
            const data = await resourceLink(sourceId, targetId);
            console.log(data)

            const formatDate = (date) => {
                let epoch = new Date(date).getTime()
                if (epoch < 16000000000) epoch *= 1000
                return new Intl.DateTimeFormat('de-DE', { dateStyle: "short", timeStyle: "short" }).format(new Date(epoch))
            }

            const container = d3.select("#sidebar #linkInfo")
            // clear container
            container.selectAll("*").remove()
            container.classed("hidden", false)

            function enterResource(enter) {
                const resourceContainer = enter
                    .append("div")
                    .classed("linkResource", true)

                const nameAndType = resourceContainer.append("div")
                    .classed("nameAndType iconTextRow", true)
                    .style("background-color", () => link.source.color)
                nameAndType.append("img")
                    .classed("categoryIcon icon", true)
                    .attr("src", d => iconUriForDataCategory(d.dataCategories[0]))
                nameAndType.append("span")
                    .classed("name text", true)
                    .text(d => d.name)

                const contract = resourceContainer.append("div")
                    .classed("contract iconTextRow", true)
                    .attr("title", "Contract")
                contract.append("span")
                    .classed("contractIcon icon", true)
                    .text("request_quote")
                contract.append("span")
                    .classed("contractText text", true)
                    .text(d => `${d.contractId}`)

                const created = resourceContainer.append("div")
                    .classed("created iconTextRow", true)
                    .attr("title", "Created")
                created.append("span")
                    .classed("createdIcon icon", true)
                    .text("playlist_add")
                created.append("span")
                    .classed("createdText text", true)
                    .text(d => `${formatDate(new Date(d.created * 1000))}`)

                const edited = resourceContainer.append("div")
                    .classed("edited iconTextRow", true)
                    .attr("title", "Last Edit")
                edited.append("span")
                    .classed("editedIcon icon", true)
                    .text("edit_note")
                edited.append("span")
                    .classed("editedText text", true)
                    .text(d => `${formatDate(new Date(d.modified * 1000))}`)

                const requests = resourceContainer.append("div")
                    .classed("reqSent iconTextRow", true)
                    .attr("title", "Requests")
                requests.append("span")
                    .classed("reqSentIcon icon", true)
                    .text("contact_support")
                requests.append("span")
                    .classed("reqSentText text", true)
                    .html(d => `${d.requestsSent} sent <br/> ${d.requestsReceived} received`)

                const responses = resourceContainer.append("div")
                    .classed("resSent iconTextRow", true)
                    .attr("title", "Responses")
                responses.append("span")
                    .classed("resSentIcon icon", true)
                    .text("reply")
                responses.append("span")
                    .classed("resSentText text", true)
                    .html(d => `${d.responsesSent} sent <br/> ${d.responsesReceived} received`)

                const description = resourceContainer.append("div")
                    .classed("description iconTextRow", true)
                description.append("span")
                    .classed("descriptionText text", true)
                    .text(d => `${d.description}`)

            }

            const outgoingDataWithTransmission = data.outgoing.filter(d => (d.requestsSent + d.requestsReceived + d.responsesSent + d.responsesReceived) > 0)
            const outgoingDataWithoutTransmission = data.outgoing.filter(d => (d.requestsSent + d.requestsReceived + d.responsesSent + d.responsesReceived) === 0)

            const outgoing = container.append("div")
                .classed("outgoing", true)
            if (data.outgoing.length > 0) {
                outgoing.selectAll(".outgoing").data(outgoingDataWithTransmission)
                    .join(
                        enterResource,
                        () => { },
                        exit => exit.remove()
                    )
            } else {
                const row = outgoing.append("div").classed("iconTextRow", true)
                row.append("div").classed("icon", true).text("code_off")
                row.append("span").classed("text", true).text("none")
            }


            if (outgoingDataWithoutTransmission.length > 0) {
                const noTransmission = container.append("div")
                    .classed("noTransmission", true)
                    .classed("show", this.noTransmissionVisible)

                const noTransHeadline = noTransmission.append("div")
                    .classed("iconTextRow noTransToggle button", true)
                    .on("click", () => {
                        this.noTransmissionVisible = !this.noTransmissionVisible;
                        this.renderLinkDetails(link)
                    })

                noTransHeadline.append("div")
                    .classed("text", true)
                    .text((this.noTransmissionVisible ? "Hide" : "Show") + " contracts without communication")

                noTransHeadline.append("div")
                    .classed("icon", true)
                    .text(() => "visibility" + (this.noTransmissionVisible ? "_off" : ""))

                noTransmission.selectAll(".noTransmission").data(outgoingDataWithoutTransmission)
                    .join(
                        enterResource,
                        () => { },
                        exit => exit.remove()
                    )
            }


        } catch (e) {
            console.log("ERROR:", e)
        }
    }

    updateData(newGraph) {
        let groupStructure
        this.graph = isParticipantView() ? ownAssociatedGraph(newGraph) : newGraph
        groupStructure = makeGroupStructure(this.graph)
        console.log("original groupStructure", groupStructure)
        this.groupStructure = { groups: [], totalCount: 0 }
        console.log("interlinks", groupStructure.interlinks)
        groupStructure.groups.forEach(g => {
            const groupData = {
                name: g.id.replace(/http[s*]:\/\/[www\.]*/, "").replace(/\/.*/, ""),
                id: g.id,
                color: g.nodes.find(n => n.color).color,
                logo: g.nodes.find(n => n.logo)?.logo,
                logobg: g.nodes.find(n => n.logobg)?.logobg,
                raw: g,
                connectors: g.nodes.filter(n => n.type !== "curator").map(connector => {
                    const resources = (connector.dataCategories?.length ?? 0) === 0 ? [{ name: "undefined" }] : connector.dataCategories
                    return {
                        name: connector.name ?? connector.id,
                        id: connector.id,
                        rawResources: connector.resources,
                        resources: resources.map((resource, resourceIndex) => ({
                            icon: iconUriForDataCategory(resource),
                            id: connector.id + "_" + resource.name,

                            links: [...g.links, ...groupStructure.interlinks]
                                .filter(link => {
                                    return (
                                        link.resources ? (
                                            // link comes from connector and has outgoing data
                                            (link.source === connector && (link.resources?.outgoing ?? []).length > 0) ||
                                            // OR link goes to connector and has incoming data
                                            (link.target === connector && (link.resources?.incoming ?? []).length > 0)
                                        ) :
                                            // OR just use source as outgoing
                                            link.source === connector
                                    )
                                        && link.source.type !== "curator" && link.target.type !== "curator"
                                })
                                .map(link => {
                                    link.source.resourceIndex = resourceIndex
                                    return link
                                })
                                .map(link => {
                                    if (link.source === connector && link.resources === undefined) return link
                                    if (link.resources !== undefined) {
                                        if (link.source === connector && link.resouces.outgoing.length > 0) return link
                                        if (link.target === connector) return {

                                            source: {
                                                ...link.target,
                                                resourceIndex: Math.max(0, link.resources.incoming.findIndex(incoming => incoming.dataCategories?.some(cat => cat === resource.name) ?? true))
                                            }, target: link.source, resources: {
                                                incoming: link.resources.outgoing,
                                                outgoing: link.resources.incoming,
                                            }
                                        }
                                    }
                                    return undefined
                                })
                                .filter(x => x !== undefined)
                        })),

                        size: resources.length,
                    }
                }),
                startsAt: 0,
                size: 0
            }

            // add this 1    v     because we need space for the data-input arc
            groupData.size = 1 + groupData.connectors.reduce((prev, curr) => {
                return prev + curr.size
            }, 0)
            this.groupStructure.groups.push(groupData)
        })
        this.groupStructure.groups.forEach((g, i) => {
            g.startsAt = this.groupStructure.groups.slice(0, i).reduce((prev, curr) => { return prev + curr.size }, 0)

            g.connectors.forEach((conn, i) => {
                conn.startsAt = g.startsAt + g.connectors.slice(0, i).reduce((prev, curr) => prev + curr.size, 0)
                conn.resources.forEach((res, i) => {
                    res.startsAt = conn.startsAt + conn.resources.slice(0, i).reduce((prev, curr) => prev + 1, 1)
                })
            })
        })
        this.groupStructure.totalCount = this.groupStructure.groups.reduce((prev, curr) => { return prev + curr.size }, 0)
        console.log(this.groupStructure)

        this.generateSVG(this.groupStructure)
    }
}