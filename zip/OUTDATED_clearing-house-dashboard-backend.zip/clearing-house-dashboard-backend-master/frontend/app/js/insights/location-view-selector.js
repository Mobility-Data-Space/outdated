export function isParticipantView() {
    return location.href.includes("view=participant")
}
export function isOperatorView() {
    return !isParticipantView()
}
export function switchView(toParticipant = !isParticipantView()) {
    if (toParticipant) {
        location.href = `${location.href}${location.href.includes("?") ? "&" : "?"}view=participant`
    } else {
        location.href = location.href.replace(/(\?|#)view=\w*/, "")
    }
}