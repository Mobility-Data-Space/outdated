import * as d3 from "d3"

/*===============================================================
    MATH
===============================================================*/

/*
    normalizes a value between min&max
*/
export function normalize(val, max, min) { return (val - min) / (max - min); }


/*
    calculates the distance between two points
*/
export function getPointDistance(x1, y1, x2, y2) {
    var xs = x2 - x1,
        ys = y2 - y1;

    xs *= xs;
    ys *= ys;

    return Math.sqrt(xs + ys);
};


/*
  returns x/y coords evenly spreaded on a circle with given radius
*/
export function getCoordsOnCircle(width, height, radius, count) {
    var coords = [];
    if (count == 1) radius = 0;
    for (var i = 0; i < count; i++) {
        var normalized = normalize(i, count, 0) - 0.5;
        var xVal = (width / 2) + (Math.cos(2 * Math.PI * normalized)) * (radius / 2) * width;
        var yVal = (height / 2) + (Math.sin(2 * Math.PI * normalized)) * (radius / 2) * height;
        coords.push({ x: xVal, y: yVal });
    }
    return coords;
}


/*
returns x/y coords for elements spreaded on a grid
*/
export function getCoordsOnGrid(width, height, rowCount, count) {
    var coords = [];
    var lineCount = Math.floor(count / rowCount);


    for (var i = 0; i < count; i++) {
        var rowNumber = i % rowCount;
        var lineNumber = Math.floor(i / rowCount);

        var normalizedX = normalize(rowNumber, rowCount, 0) - 0.5;
        var normalizedY = -1 * normalize(lineNumber, lineCount, 0) - 0.5;

        var xVal = normalizedX * width;
        var yVal = normalizedY * height;
        coords.push({ x: xVal, y: yVal });
    }
    return coords;
}

/*===============================================================
    COLORS
===============================================================*/

/*
    multiply colors
*/
export const multiplyColor = (rgb1, rgb2) => rgb1.map((c, i) => Math.floor(c * rgb2[i] / 255))


export function allpermutations(xs) {
    let ret = [];

    for (let i = 0; i < xs.length; i = i + 1) {
        let rest = allpermutations(xs.slice(0, i).concat(xs.slice(i + 1)));

        if (!rest.length) {
            ret.push([xs[i]])
        } else {
            for (let j = 0; j < rest.length; j = j + 1) {
                ret.push([xs[i]].concat(rest[j]))
            }
        }
    }
    return ret;
}

export function last(array) {
    return array[array.length - 1]
}


/*===============================================================
    SVG MAGIC
===============================================================*/

export function samples(path, precision) {
    var n = path.getTotalLength(), t = [0], i = 0, dt = precision;
    while ((i += dt) < n) t.push(i);
    t.push(n);
    return t.map(function (t) {
        var p = path.getPointAtLength(t), a = [p.x, p.y];
        a.t = t / n;
        return a;
    });
}

// Compute quads of adjacent points [p0, p1, p2, p3].
export function quads(points) {
    return d3.range(points.length - 1).map(function (i) {
        var a = [points[i - 1], points[i], points[i + 1], points[i + 2]];
        a.t = (points[i].t + points[i + 1].t) / 2;
        return a;
    });
}

// Compute stroke outline for segment p12.
export function lineJoin(p0, p1, p2, p3, width) {
    var u12 = perp(p1, p2),
        r = width / 2,
        a = [p1[0] + u12[0] * r, p1[1] + u12[1] * r],
        b = [p2[0] + u12[0] * r, p2[1] + u12[1] * r],
        c = [p2[0] - u12[0] * r, p2[1] - u12[1] * r],
        d = [p1[0] - u12[0] * r, p1[1] - u12[1] * r];

    // if (p0) { // clip ad and dc using average of u01 and u12
    //     var u01 = perp(p0, p1), e = [p1[0] + u01[0] + u12[0], p1[1] + u01[1] + u12[1]];
    //     a = lineIntersect(p1, e, a, b);
    //     d = lineIntersect(p1, e, d, c);
    // }

    // if (p3) { // clip ab and dc using average of u12 and u23
    //     var u23 = perp(p2, p3), e = [p2[0] + u23[0] + u12[0], p2[1] + u23[1] + u12[1]];
    //     b = lineIntersect(p2, e, a, b);
    //     c = lineIntersect(p2, e, d, c);
    // }

    return "M" + a + "L" + b + " " + c + " " + d + "Z";
}

// Compute intersection of two infinite lines ab and cd.
function lineIntersect(a, b, c, d) {
    var x1 = c[0], x3 = a[0], x21 = d[0] - x1, x43 = b[0] - x3,
        y1 = c[1], y3 = a[1], y21 = d[1] - y1, y43 = b[1] - y3,
        ua = (x43 * (y1 - y3) - y43 * (x1 - x3)) / (y43 * x21 - x43 * y21);
    return [x1 + ua * x21, y1 + ua * y21];
}

// Compute unit vector perpendicular to p01.
function perp(p0, p1) {
    var u01x = p0[1] - p1[1], u01y = p1[0] - p0[0],
        u01d = Math.sqrt(u01x * u01x + u01y * u01y);
    return [u01x / u01d, u01y / u01d];
}
