
/**
 * @typedef Node
 * @type {object}
 * @property {string} id
 * @property {string} group
 * @property {string} name
 * @property {string} type
 * @property {string} logo
 * @property {string} color
 * @property {boolean} owned
 * @property {Category} dataCategories
 * @property {url} string
 */

import { allpermutations } from "./utils"

/**
 * @typedef Link
 * @type {object}
 * @property {string} source
 * @property {string} target
 */

/**
 * @typedef Graph
 * @type {object}
 * @property {Node[]} nodes
 * @property {Link[]} links
 */

/**
 * @typedef Category
 * @type {object}
 * @property {string} name
 */

/**
 * Reduces a given graph to the relevant elements for the given main group.
 * The resulting graph will contain the connectors in the main group, the connectors linked to these and all the respective curators
 * @param {Graph} graph the graph to reduce
 * @param {string} mainGroup the group contained completely
 * @returns {Graph} the reduced graph
 */
export function associatedGraph(graph, mainGroup) {

    // in participant view
    // don't show connectors or curators that aren't directly connected
    const participantGroupNodes = graph.nodes.filter(n => n.group === mainGroup)
    const relevantLinks = graph.links.filter(link => {
        const source = graph.nodes.find(n => n.id === link.source)
        const target = graph.nodes.find(n => n.id === link.target)
        const linkedToParticipant = (participantGroupNodes.some(n => n.id === source.id) || participantGroupNodes.some(n => n.id === target.id))
        const linkedToCuratorOfLinked = (source.type === "curator" || target.type === "curator") && graph.links.some(l => {
            const source2 = graph.nodes.find(n => n.id === l.source)
            const target2 = graph.nodes.find(n => n.id === l.target)
            if ((source === source2 ||
                source === target2 ||
                target === source2 ||
                target === target2) &&
                (source2.group === mainGroup || target2.group === mainGroup)) {
                return true
            }
            return false

        })
        return linkedToParticipant || linkedToCuratorOfLinked
    })
    const relevantNodes = graph.nodes.filter(node => {
        // is one of participant nodes
        if (node.group === mainGroup) return true;

        // is linked to one of participant nodes
        if (relevantLinks.some(l => (l.source === node.id || l.target === node.id))) return true;

        // is curator of a connected node
        if (node.type === "curator") {
            return relevantLinks.some(l => {
                const source = graph.nodes.find(n => n.id === l.source)
                const target = graph.nodes.find(n => n.id === l.target)
                if (source.group === node.group || target.group === node.group) return true;
                return false
            })
        }
    })
    return {
        nodes: relevantNodes,
        links: relevantLinks
    }
}

/**
 * Reduces the graph to all nodes relevant for the nodes marked as owned
 * @param {Graph} baseGraph 
 */
export function ownAssociatedGraph(baseGraph) {
    const ownGroup = baseGraph.nodes.find(x => x.owned)?.group
    if (!ownGroup) {
        console.warn("no own connector found")
    }
    return associatedGraph(baseGraph, ownGroup)
}

/**
 * ensures every node has a group-attribute, generates one if missing.
 * @param {Graph} graph 
 * @returns {Graph} a graph will group attribute on all nodes
 */
export function fillMissingGroups(graph) {
    let allHaveGroups = true
    const existingGroups = new Set()
    for (const node of graph.nodes) {
        if (node.group) {
            existingGroups.add(node.group)
        } else {
            allHaveGroups = false
        }
    }
    if (allHaveGroups) return graph
    let generatedGroups = 0
    function generateGroup() {
        let generatedName
        do {
            generatedGroups++
            generatedName = "AUTO_GENERATED_" + generatedGroups
        } while (existingGroups.has(generatedName))
        return generatedName
    }
    return {
        ...graph,
        nodes: graph.nodes.map(node => node.group ? node : { ...node, group: generateGroup() })
    }
}

export function colorGroupwise(graph, defaultColor) {
    graph = fillMissingGroups(graph) // ensure every node has a group
    const groupColors = new Map()
    for (const node of graph.nodes) {
        if (node.color) {
            // a curator always overrides the color of the group
            if (node.type === "curator" || !groupColors.has(node.group)) {
                groupColors.set(node.group, node.color)
            }
        }
    }
    const coloredNodes = graph.nodes.map((node) => {
        if (node.color) return node
        return { ...node, color: groupColors.has(node.group) ? groupColors.get(node.group) : defaultColor }
    })
    return {
        ...graph,
        nodes: coloredNodes
    }
}

export function applyPresets(graph, presets) {
    const nodes = !presets.nodes ? graph.nodes : graph.nodes.map(node => {
        const preset = presets.nodes.find(p => p.id === node.id);
        return preset ? { ...preset, ...node } : node
    })
    const links = !presets.links ? graph.links : graph.links.map(link => {
        const preset = presets.links.find(p => (p.source === link.source) && (p.target === link.target))
        return preset ? { ...preset, ...link } : link
    })
    return { ...graph, nodes, links }
}

/**
 * @typedef LinkObject
 * @type {object}
 * @property {Node} source
 * @property {Node} target
 */

/**
 * @typedef Group
 * @type {object}
 * @property {string} id
 * @property {Node[]} nodes
 * @property {LinkObject[]} links
 */


/**
 * generates group based data from a Graph
 * @param {Graph} graph to be converted into group based structure
 * @returns {{groups: Group[], interlinks: LinkObject[]}
 */
export function makeGroupStructure(graph) {
    const groups = []
    graph.nodes.forEach(node => {
        const group = groups.find(g => g.id === node.group)
        if (group !== undefined) {
            group.nodes.push(node)
            if (node.owned) {
                group.owned = true
            }
        } else {
            groups.push({
                id: node.group,
                nodes: [node],
                links: [],
                owned: node.owned
            })
        }
    })
    graph.links.forEach(link => {
        const source = graph.nodes.find(node => node.id === link.source);
        const target = graph.nodes.find(node => node.id === link.target);
        if (source.group === target.group) {
            groups.find(group => group.id === source.group).links.push({ ...link, source, target })
        }
    })
    groups.sort((a, b) => a.id < b.id ? -1 : 1)
    return {
        groups,
        interlinks: getInterLinks(graph)
    }
}

/**
 * 
 * @param {Group[]} groups 
 * @param {string} sortBy 
 * @param {boolean} reverse 
 * @param {Graph} graph ? optional
 * @returns 
 */
export function sortGroupStructure(groups, sortBy, reverse = false, graph) {
    switch (sortBy.toLowerCase()) {
        case "alphabetically":
            groups.sort((a, b) => {
                const curatorA = a.nodes.find(node => node.type === "curator")
                const curatorB = b.nodes.find(node => node.type === "curator")
                return curatorA.name < curatorB.name ? -1 : 1;
            });
            break;
        case "connector count":
            groups.sort((a, b) => {
                return b.nodes.filter(node => node.type === "connector").length - a.nodes.filter(node => node.type === "connector").length
            });
            break;
        case "random":
            groups.sort(() => (Math.random() * 2 - 1))
            break;

        case "least_overlaps": {
            if (graph !== undefined) {
                sortByLeastOverlaps(groups, getInterLinks(graph))
            }
            break;
        }
    }

    if (reverse) {
        groups.reverse()
    }
    return groups
}

/**
 * 
 * @param {Group[]} group 
 * @returns {LinkObject[]}
 */
export function getIntraLinks(groupStructure) {
    return groupStructure.flatMap(group => group.links)
}

/**
 * 
 * @param {Graph} graph 
 * @returns {LinkObject[]} links interconnecting groups
 */
export function getInterLinks(graph) {
    return graph.links.map(link => {
        const sourceNode = graph.nodes.find(node => node.id === link.source)
        const targetNode = graph.nodes.find(node => node.id === link.target)
        if (sourceNode.group !== targetNode.group) {
            return { ...link, source: sourceNode, target: targetNode }
        }
        else return undefined
    }).filter(linkObj => linkObj !== undefined)
}

/**
 * @typedef LinkLocation
 * @type {object}
 * @property {number} a
 * @property {number} b
 * @property {number} bIndex
 * @property {LinkObject} link
 */

/**
 * @param {Group} ownGroup
 * @param {Group[]} otherGroups 
 * @param {LinkObject[]} interlinks 
 * @returns {LinkLocation[]}
 */
function getLinkLocations(ownGroup, otherGroups, interlinks) {
    return interlinks
        // map link to locations
        .map(link => {
            const locationInOwnGroup = ownGroup.nodes.findIndex((ownNode) =>
                (ownNode === link.source) || (ownNode === link.target)
            ) / ownGroup.nodes.length

            const otherGroup = otherGroups.find(g => g.nodes.some(node => node === link.target || node === link.source))
            const locationInOtherGroup = otherGroup.nodes.findIndex((otherNode) =>
                (otherNode === link.source) || (otherNode === link.target)
            ) / otherNode.nodes.length

            const otherGroupIndex = otherGroups.indexOf(otherGroup)

            return {
                a: locationInOwnGroup,
                b: locationInOtherGroup,
                bIndex: otherGroupIndex,
                link,
            }
        })
}

function sortByLeastOverlaps(groups, interlinks) {
    const ownGroup = groups.find(group => group.nodes.some(node => node.owned))
    const otherGroups = groups.filter(group => group !== ownGroup)

    /**
     * @property {LinkLocation} linkLocations
     */
    let linkLocations = getLinkLocations(groups, interlinks)

    const mapping = allpermutations(otherGroups.map((_, i) => i))

    const overlaps = mapping.map(m => {
        let overlaps = 0
        linkLocations.forEach((ll) => {
            linkLocations.forEach((ll2) => {
                if (ll.a === ll2.a || ll.b === ll2.b) return
                const a = ll.a < ll2.a;
                const b = (ll.b + m[ll.bIndex]) < (ll2.b + m[ll2.bIndex])
                if (a !== b) {
                    overlaps++;
                }
            })
        })
        return {
            mapping: m,
            overlaps
        }
    })

    overlaps.sort((a, b) => a.overlaps - b.overlaps)
    const m = overlaps[0]?.mapping
    if (m) {
        groups.sort((a, b) => {
            const aInd = groups.indexOf(a)
            const bInd = groups.indexOf(b)
            return m[aInd] - m[bInd]
        })
    }
}