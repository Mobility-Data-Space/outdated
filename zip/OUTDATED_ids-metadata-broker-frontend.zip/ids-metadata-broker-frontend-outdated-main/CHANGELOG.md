  IDS Metadata Broker - Open Frontend                                      
---------

Version 1.0 - Initial Release
