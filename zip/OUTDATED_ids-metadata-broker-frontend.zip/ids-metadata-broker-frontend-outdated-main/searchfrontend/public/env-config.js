window._env_ = {
  REACT_APP_USE_GEO_NAMES: "true",
  REACT_APP_USE_SPARQL: "false",
  REACT_APP_BROKER_URL: "http://localhost:9200",
}
